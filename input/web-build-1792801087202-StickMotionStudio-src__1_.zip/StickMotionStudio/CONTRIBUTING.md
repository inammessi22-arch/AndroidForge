# Contributing to StickMotion Studio

1. Keep the `core/` module pure Kotlin (no `android.*` imports) so it stays
   unit-testable on the JVM. Put Android dependencies in `render/`, `data/`,
   `ui/`, `viewmodel/`.
2. Add unit tests for any new core logic. Run `standalone-test/run.sh` and
   `./gradlew :app:testDebugUnitTest` before opening a PR.
3. Do not add GPL-licensed or unlicensed code without first discussing
   relicensing (the project is Apache-2.0). See docs/COMPONENT_EVALUATION.md.
4. Never commit secrets, keystores, or API keys. Signing is via environment
   variables (docs/PLAY_RELEASE.md).
5. Original assets only — do not copy competitor UI, trademarks, or branded
   icons.
6. Format: `./gradlew ktlintFormat` (add ktlint if desired); default Kotlin style.
7. PRs should include a short test result note. By contributing you license
   your work under Apache-2.0.
