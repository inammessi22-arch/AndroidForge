# Dependency & License Inventory

Generated from app/build.gradle.kts. Last updated 2026-10-23.

| Dependency | Version | License | Scope | Purpose |
|---|---|---|---|---|
| org.jetbrains.kotlin:kotlin-stdlib | 1.9.24 | Apache-2.0 | implementation | Language runtime |
| org.jetbrains.kotlinx:kotlinx-serialization-json | 1.6.3 | Apache-2.0 | implementation | Project JSON (.sms.json) |
| androidx.core:core-ktx | 1.13.1 | Apache-2.0 | implementation | Kotlin Android extensions |
| androidx.activity:activity-compose | 1.9.2 | Apache-2.0 | implementation | Compose host activity |
| androidx.compose:compose-bom | 2024.09.02 | Apache-2.0 | implementation | Compose UI (ui, ui-graphics, material3, tooling) |
| androidx.lifecycle:lifecycle-viewmodel-compose | 2.8.6 | Apache-2.0 | implementation | ViewModels |
| androidx.lifecycle:lifecycle-runtime-compose | 2.8.6 | Apache-2.0 | implementation | StateFlow collection |
| junit:junit | 4.13.2 | EPL-1.0 | testImplementation | Unit tests (not bundled) |

## Build toolchain
- Android Gradle Plugin 8.7.2, Gradle 8.9, JDK 17, compileSdk 35, minSdk 24, targetSdk 35.
- Compose compiler 1.5.14 (matched to Kotlin 1.9.24).

## Permissions
- READ_MEDIA_IMAGES / READ_MEDIA_AUDIO / READ_MEDIA_VIDEO (only for user-initiated import via system picker).
- FOREGROUND_SERVICE + FOREGROUND_SERVICE_SPECIAL_USE (MP4 rendering survives screen-off).
- POST_NOTIFICATIONS (export progress).
- **No INTERNET permission.** The app is 100% offline-first; no analytics, no ads, no cloud.

## No secrets
No API keys, tokens, or signing credentials are in the repository. Release
signing uses a local keystore referenced by environment variables — see
docs/PLAY_RELEASE.md.
