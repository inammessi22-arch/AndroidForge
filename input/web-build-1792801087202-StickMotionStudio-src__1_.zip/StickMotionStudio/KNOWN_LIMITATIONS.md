# Known Limitations & Prioritized Remaining Tasks

Ordered by priority for a first public release.

## P0 — must fix before Play release
1. **Compile the Android layer.** Environment had no Android SDK/JDK 17. Run
   `./gradlew :app:assembleDebug` and fix any import/version errors. The core
   (76/76 tests) is verified; UI/export code is written but uncompiled.
2. **On-device smoke test:** create project, drag a joint, set 2 keyframes,
   play, save/reopen, export 720p MP4, verify file plays.
3. **Verify MediaCodec input-Surface path** on API 24–35; some devices need
   `BUFFER_FLAG_END_OF_STREAM` handling or codec-specific color format. Add
   fallback to YUV-buffer encoding if Surface input fails.
4. **Audio muxing** is passthrough-only and best-effort. Non-AAC/MP3 audio is
   silently skipped (video still exports). For v1.1: transcode to AAC via
   MediaCodec audio decoder+encoder.
5. **Rename flow** in HomeScreen uses a placeholder (`promptRename`). Replace
   with an AlertDialog containing a TextField.

## P1 — quality
6. Add instrumented tests (androidTest) for StageCanvas touch & ExportService.
7. Thumbnails in gallery (render first frame to PNG on save).
8. Props layer (simple shapes) — model exists conceptually, UI not wired.
9. Onion-skinning (show previous/next frame ghost) — renderer supports it via
   extra draw pass; add toggle.
10. Audio scrub/preview during playback (MediaPlayer synced to playhead).

## P2 — polish
11. Pivot/Stick Nodes project import — would require GPL-3.0 if ported from
    StykAnimate; implement clean-room or relicense project first.
12. Gesture: two-finger zoom/pan of stage.
13. More easing curves (bezier) + per-keyframe easing picker UI.
14. Cloud sync (optional, off by default, would require INTERNET permission).

## Not planned (by design)
- Proprietary AI API dependency, login, subscription, ads, analytics.
- Copying GPL-licensed or unlicensed third-party code.
