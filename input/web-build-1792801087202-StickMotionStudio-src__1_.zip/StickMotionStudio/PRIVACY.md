# Privacy Policy — StickMotion Studio

**Data collected: none.** StickMotion Studio does not require or use the
INTERNET permission. It has no analytics, no advertising SDK, no crash
reporting, no cloud sync, and no account system.

## What happens to your data
- Projects, imported images, and imported audio are stored **only on your
  device** (app-private storage) unless you explicitly export them via the
  system file picker to a location you choose.
- Imported media (images/audio) is accessed through Android's Storage Access
  Framework; the app only reads the files you pick.
- MP4 exports are written to a location you choose via the system picker.

## Permissions and why
| Permission | Why |
|---|---|
| READ_MEDIA_IMAGES / AUDIO / VIDEO | Only when you choose to import media via the system picker. |
| FOREGROUND_SERVICE (+ SPECIAL_USE) | MP4 rendering continues while screen is off. |
| POST_NOTIFICATIONS | Shows export progress. You can deny it; export still works silently. |

No personal data leaves the device. If you redistribute this app with added
analytics or cloud features, you must update this policy and add the INTERNET
permission.
