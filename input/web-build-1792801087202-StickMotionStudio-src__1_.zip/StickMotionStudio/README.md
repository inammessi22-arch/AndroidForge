# StickMotion Studio

Free, open-source Android stickman animation editor. Design stickman
characters, pose joints by dragging, set keyframes, combine motion presets,
add backgrounds & audio, save editable projects, and export real MP4 videos.

100% offline-first. No account, no subscription, no cloud, no ads, no
analytics. No internet permission at all.

> **Status (2026-10-23):** MVP source complete. The pure animation core
> (skeleton, FK/IK, keyframes, interpolation, presets, JSON serialization,
> undo/redo) is **unit-tested: 76/76 passing** in a standalone Kotlin harness
> (see `standalone-test/`). The Android UI + MediaCodec MP4 export layer is
> written but **could not be compiled in the build environment** (no Android
> SDK / JDK 17 available there). See "Build status" below before release.

## Features

- [x] Dark-theme home screen + project gallery (create / open / rename / duplicate / delete)
- [x] Stickman skeleton: head, torso, shoulders, elbows, wrists, hips, knees, ankles (16 joints)
- [x] Touch drag with two-bone analytic IK for wrists & ankles; single-bone rotate for other joints
- [x] Timeline: keyframes, play/pause, scrub, frame stepping, FPS (12/24/30/60), duration
- [x] Interpolation: linear / ease-in / ease-out / ease-in-out / hold; shortest-path angle lerp
- [x] Looping playback (vsync-synced)
- [x] Undo / redo (50 steps) + copy / paste pose
- [x] Motion presets: walk, run, jump, wave, fall, punch, kick, dance (editable after apply)
- [x] Multiple characters with independent tracks, layers, visibility, per-character colors
- [x] Background color + imported image (cover/contain/stretch)
- [x] Local project saving (.sms.json), autosave (debounced), validated JSON import/export
- [x] Audio import (SAF) + best-effort passthrough mux into MP4
- [x] Genuine MP4 export via MediaCodec (AVC) + MediaMuxer; 720p/1080p, 9:16 / 16:9 / 1:1
- [x] Foreground-service export with progress notification, cancellation, error handling
- [x] In-app Open Source Licenses screen
- [x] Beginner onboarding (3 slides), content descriptions on controls
- [ ] Instrumented (on-device) tests — needs Android emulator/device
- [ ] On-device MP4 export verification — needs a real device

## Architecture

```
core/      Pure Kotlin (no Android): Vec2, Skeleton, Pose, FK, IK, Easing,
           Keyframe, Track, Character, Project, Presets — unit-testable on JVM.
data/      ProjectRepository (atomic JSON save/load), ProjectSerializer
           (kotlinx.serialization DTOs + validation).
render/    SceneRenderer (draws project→Canvas, shared by editor & exporter),
           Mp4Exporter (MediaCodec + input Surface + MediaMuxer), ExportService.
ui/        Jetpack Compose: HomeScreen, EditorScreen, StageCanvas,
           TimelineStrip, TransportControls, ExportDialog, LicensesScreen,
           OnboardingScreen.
viewmodel/ EditorViewModel, GalleryViewModel (single source of truth + undo).
util/      History<T> undo/redo stack.
```

## Build instructions

Requires **JDK 17**, Android Studio Ladybug+ or command-line SDK with
platform 35 and build-tools.

```bash
# 1. Generate the Gradle wrapper (jar not committed):
gradle wrapper --gradle-version 8.9
# 2. Debug build + unit tests:
./gradlew :app:assembleDebug
./gradlew :app:testDebugUnitTest
# 3. Release AAB (signing config via env vars, see docs/PLAY_RELEASE.md):
./gradlew :app:bundleRelease
```

## Run the standalone core tests (no Android SDK needed)

```bash
cd standalone-test && ./run.sh
# Expected: "RESULT: 76 passed, 0 failed"
```

## Build status & honest limitations

The environment that produced this source had **Java 11 only, no Gradle, no
Android SDK**. Therefore:
- The Kotlin core was compiled and tested with a standalone `kotlinc` 1.9.24
  + kotlinx-serialization compiler plugin — **76/76 tests pass**.
- The Android layer (Compose UI, Manifest, Gradle, MediaCodec export) is
  **written but not yet compiled**. Expect minor import/version fixes on first
  `assembleDebug`. See KNOWN_LIMITATIONS.md for the prioritized fix list.
- No APK/AAB was built, signed, or uploaded. Do not claim Play release is
  complete — see docs/PLAY_RELEASE.md for the exact remaining steps.

## License

Original code: **Apache-2.0** (see LICENSE). Third-party components: see
THIRD_PARTY_NOTICES.md and DEPENDENCIES.md. **No GPL-licensed code is
included.** Evaluated repos (StykAnimate, mooltik — both GPL-3.0;
hmelberg/stick — unlicensed) were not reused; see docs/COMPONENT_EVALUATION.md.

## Contributing

See CONTRIBUTING.md. Short version: Apache-2.0 DCO-style sign-off, no
secrets in PRs, keep the core pure-Kotlin so it stays unit-testable.
