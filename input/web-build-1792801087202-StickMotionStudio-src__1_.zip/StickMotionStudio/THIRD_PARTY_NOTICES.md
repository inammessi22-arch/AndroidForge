# Third-Party Notices — StickMotion Studio

StickMotion Studio (original code) is licensed under the Apache License,
Version 2.0 (see LICENSE). It contains or depends on the following
third-party components. Their copyright notices and license terms are
preserved here as required.

---

## 1. Kotlin standard library & kotlinx-serialization
- Copyright © JetBrains s.r.o.
- License: Apache License 2.0 — https://github.com/JetBrains/kotlin/blob/master/license/LICENSE.txt
- Used for: language runtime, JSON project file format.

## 2. Android Open Source Project (AndroidX, Jetpack Compose, Material3, framework MediaCodec/MediaMuxer/MediaExtractor)
- Copyright © The Android Open Source Project
- License: Apache License 2.0 — https://source.android.com/setup/start/licenses
- Used for: UI framework, video encoding, audio muxing.

## 3. JUnit 4 (development/testing only — NOT included in the distributed APK)
- Copyright © The JUnit Team
- License: Eclipse Public License 1.0 — https://www.eclipse.org/legal/epl-v10.html
- Used for: unit tests.

## 4. Gradle (build tool — NOT bundled in the distributed APK)
- Copyright © Gradle Inc.
- License: Apache License 2.0 — https://github.com/gradle/gradle/blob/master/LICENSE
- Used for: building the app.

---

## Components explicitly NOT included (evaluated and rejected)
- **StykAnimate-App** (filippocalippo) — GPL-3.0, Electron/WebGPU desktop/web. No code copied.
- **mooltik** (ruskakimov) — GPL-3.0, Flutter frame-by-frame drawing. No code copied.
- **hmelberg/stick** — unlicensed (all rights reserved). No code copied; reuse would require explicit permission.

## Modified third-party components
None. All bundled components are used unmodified via their published artifacts.

## How to comply when redistributing
1. Keep this file and LICENSE in the source tree and in the app's
   "Open Source Licenses" screen (app/src/main/.../LicensesScreen.kt).
2. If you redistribute the APK/AAB, include a copy of these notices in the
   app (already done via the in-app Licenses screen).
3. If you add GPL-licensed code, relicense the whole project GPL-3.0 and
   offer corresponding source. See docs/COMPONENT_EVALUATION.md.
