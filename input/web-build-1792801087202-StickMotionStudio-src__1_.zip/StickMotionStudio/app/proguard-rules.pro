# Keep kotlinx.serialization generated serializers
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class com.stickmotion.studio.data.**$$serializer { *; }
-keepclassmembers class com.stickmotion.studio.data.** {
    *** Companion;
}
-keepclasseswithmembers class com.stickmotion.studio.data.** {
    kotlinx.serialization.KSerializer serializer(...);
}
# Keep model classes used by reflection-free serialization (DTOs are in data.**)
-keep class com.stickmotion.studio.data.** { *; }
