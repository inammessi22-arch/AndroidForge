package com.stickmotion.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.stickmotion.studio.ui.screens.EditorScreen
import com.stickmotion.studio.ui.screens.HomeScreen
import com.stickmotion.studio.ui.screens.LicensesScreen
import com.stickmotion.studio.ui.screens.OnboardingScreen
import com.stickmotion.studio.ui.theme.StickMotionTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("stickmotion", MODE_PRIVATE)
        val showOnboarding = !prefs.getBoolean("onboarding_done", false)
        setContent {
            StickMotionTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(
                        initialOnboarding = showOnboarding,
                        onOnboardingDone = { prefs.edit().putBoolean("onboarding_done", true).apply() }
                    )
                }
            }
        }
    }
}

@Composable
private fun AppRoot(initialOnboarding: Boolean, onOnboardingDone: () -> Unit) {
    sealed class Screen {
        data object Onboarding : Screen()
        data object Home : Screen()
        data class Editor(val projectId: String) : Screen()
        data object Licenses : Screen()
    }
    var screen by remember { mutableStateOf<Screen>(if (initialOnboarding) Screen.Onboarding else Screen.Home) }
    when (val s = screen) {
        Screen.Onboarding -> OnboardingScreen(onDone = { onOnboardingDone(); screen = Screen.Home })
        Screen.Home -> HomeScreen(
            onOpenProject = { screen = Screen.Editor(it) },
            onShowLicenses = { screen = Screen.Licenses }
        )
        is Screen.Editor -> EditorScreen(
            projectId = s.projectId,
            onBack = { screen = Screen.Home }
        )
        Screen.Licenses -> LicensesScreen(onBack = { screen = Screen.Home })
    }
}
