package com.stickmotion.studio

import android.app.Application
import com.stickmotion.studio.data.ProjectRepository

class StickMotionApp : Application() {
    lateinit var repository: ProjectRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = ProjectRepository(this)
    }
}
