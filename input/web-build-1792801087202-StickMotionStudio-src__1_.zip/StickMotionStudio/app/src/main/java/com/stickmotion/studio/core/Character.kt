package com.stickmotion.studio.core

/** A stickman character with its own skeleton config and animation track. */
data class Character(
    val id: String,
    val name: String,
    val config: StickmanConfig,
    val track: Track,
    val visible: Boolean = true,
    /** Higher layer draws on top. */
    val layer: Int = 0
) {
    fun withTrack(t: Track): Character = copy(track = t)
    fun withConfig(c: StickmanConfig): Character = copy(config = c)
    fun withName(n: String): Character = copy(name = n)
    fun withVisible(v: Boolean): Character = copy(visible = v)

    fun poseAt(frame: Float): Pose = track.poseAt(frame)

    companion object {
        private var counter = 0
        fun newId(): String {
            counter++
            return "char_${counter}_${System.identityHashCode(Any())}"
        }
    }
}

/** Optional imported audio clip, synced by start frame. */
data class AudioTrack(
    val id: String,
    /** Persisted content:// URI (SAF) or asset-relative path. */
    val sourceUri: String,
    val startFrame: Int = 0,
    val volume: Float = 1f,
    val name: String = "Audio"
)

/** Stage background: solid color and/or an imported image (stretched to stage). */
data class Background(
    val colorArgb: Int = 0xFF1A1C1E.toInt(),
    val imageUri: String? = null,
    val imageFit: Fit = Fit.COVER
) {
    enum class Fit { COVER, CONTAIN, STRETCH }
}

/** Output resolution + aspect ratio presets for MP4 export. */
data class ExportConfig(
    val width: Int,
    val height: Int,
    val fps: Int,
    val includeAudio: Boolean = true
) {
    enum class Preset(val label: String, val w: Int, val h: Int) {
        P720_PORTRAIT("720p 9:16", 720, 1280),
        P720_LANDSCAPE("720p 16:9", 1280, 720),
        P720_SQUARE("720p 1:1", 720, 720),
        P1080_PORTRAIT("1080p 9:16", 1080, 1920),
        P1080_LANDSCAPE("1080p 16:9", 1920, 1080),
        P1080_SQUARE("1080p 1:1", 1080, 1080)
    }

    companion object {
        val DEFAULT = ExportConfig(720, 1280, 24, true)
    }
}
