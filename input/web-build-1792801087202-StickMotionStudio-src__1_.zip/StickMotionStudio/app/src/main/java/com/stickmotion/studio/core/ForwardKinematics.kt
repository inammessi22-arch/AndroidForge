package com.stickmotion.studio.core

/**
 * Forward kinematics: resolves a [Pose] + [StickmanConfig] into world-space
 * joint positions and bone segments. Used by both the interactive renderer
 * and the offline MP4 frame renderer, so it is pure and deterministic.
 */
object ForwardKinematics {

    data class Result(
        /** World position of every joint. */
        val positions: Map<JointId, Vec2>,
        /** Drawable bone segments (start, end, stroke width) in draw order. */
        val bones: List<Bone>,
        val headCenter: Vec2,
        val headRadius: Float
    )

    data class Bone(val from: Vec2, val to: Vec2, val width: Float)

    fun solve(pose: Pose, cfg: StickmanConfig): Result {
        val pos = HashMap<JointId, Vec2>(JointId.ALL.size)
        val worldAngle = HashMap<JointId, Float>(JointId.ALL.size)

        pos[JointId.HIPS] = pose.root
        worldAngle[JointId.HIPS] = 0f // spine base direction = +y (up)

        // Parent-before-child traversal (enum order is already topological).
        for (j in JointId.ALL) {
            if (j.isRoot) continue
            val parent = j.parent!!
            val parentPos = pos[parent]!!
            val parentAngle = worldAngle[parent]!!

            val lateral = cfg.lateralOffsetOf(j)
            val len = cfg.lengthOf(j)
            val localAngle = pose.angleOf(j)
            val angle = parentAngle + localAngle
            worldAngle[j] = angle

            // Offset joints sit perpendicular to the parent bone direction.
            val lateralVec = if (lateral != 0f) {
                // perpendicular to parent direction (rotate +90deg = character left)
                Vec2.UP.rotate(parentAngle).rotate(deg(90f)) * lateral
            } else Vec2.ZERO

            val boneDir = Vec2.UP.rotate(angle)
            pos[j] = parentPos + lateralVec + boneDir * len
        }

        val bones = mutableListOf<Bone>()
        val w = cfg.strokeWidth
        fun addBone(from: JointId, to: JointId) {
            // If 'from' is an offset joint, draw from its world position.
            bones.add(Bone(pos[from]!!, pos[to]!!, w))
        }
        // Torso chain
        addBone(JointId.HIPS, JointId.CHEST)
        addBone(JointId.CHEST, JointId.NECK)
        // Arms
        addBone(JointId.L_SHOULDER, JointId.L_ELBOW); addBone(JointId.L_ELBOW, JointId.L_WRIST)
        addBone(JointId.R_SHOULDER, JointId.R_ELBOW); addBone(JointId.R_ELBOW, JointId.R_WRIST)
        // Legs
        addBone(JointId.L_HIP, JointId.L_KNEE); addBone(JointId.L_KNEE, JointId.L_ANKLE)
        addBone(JointId.R_HIP, JointId.R_KNEE); addBone(JointId.R_KNEE, JointId.R_ANKLE)
        // Shoulder/hip cross bars so the figure reads as a body
        bones.add(Bone(pos[JointId.L_SHOULDER]!!, pos[JointId.R_SHOULDER]!!, w * 0.8f))
        bones.add(Bone(pos[JointId.L_HIP]!!, pos[JointId.R_HIP]!!, w * 0.8f))

        return Result(
            positions = pos,
            bones = bones,
            headCenter = pos[JointId.HEAD]!!,
            headRadius = cfg.headRadius
        )
    }
}
