package com.stickmotion.studio.core

/**
 * Easing curves applied to the normalized time [t] in [0,1] between two
 * keyframes. Pure functions — verified by unit tests.
 */
enum class Easing {
    HOLD,       // snap to previous keyframe until the next (step function)
    LINEAR,
    EASE_IN,
    EASE_OUT,
    EASE_IN_OUT;

    fun apply(t: Float): Float = when (this) {
        HOLD -> if (t >= 1f) 1f else 0f
        LINEAR -> t.coerceIn(0f, 1f)
        EASE_IN -> t * t
        EASE_OUT -> 1f - (1f - t) * (1f - t)
        EASE_IN_OUT -> if (t < 0.5f) 2f * t * t else 1f - ((-2f * t + 2f) * (-2f * t + 2f)) / 2f
    }
}
