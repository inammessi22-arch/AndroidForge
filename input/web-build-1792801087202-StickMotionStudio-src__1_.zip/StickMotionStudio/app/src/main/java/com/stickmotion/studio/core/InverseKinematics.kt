package com.stickmotion.studio.core

import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Two-bone analytic IK for arms (shoulder-elbow-wrist) and legs (hip-knee-ankle).
 * Given the world position of the chain root and a desired end-effector target,
 * returns the local angles to set on the two bones.
 *
 * Pure math, fully unit-testable. Bend sign picks the elbow/knee bend
 * direction (+ = forward bend, - = backward bend).
 */
object InverseKinematics {

    data class Solution(
        /** Angle of bone 1 (upper arm / thigh) relative to parent direction. */
        val angle1: Float,
        /** Angle of bone 2 (forearm / shin) relative to bone 1. */
        val angle2: Float,
        /** True when target was reachable; false means clamped to max reach. */
        val reached: Boolean
    )

    /**
     * @param rootPos world position of the chain root (shoulder or hip)
     * @param parentWorldAngle world-space direction angle of the parent bone
     *        (the spine for shoulders, 0/down-reference for hips) — used to
     *        convert the result into local angles.
     * @param target desired end-effector world position
     * @param len1 length of upper bone
     * @param len2 length of lower bone
     * @param bendSign +1 or -1 chooses elbow/knee direction
     */
    fun solve2Bone(
        rootPos: Vec2,
        parentWorldAngle: Float,
        target: Vec2,
        len1: Float,
        len2: Float,
        bendSign: Float
    ): Solution {
        val delta = target - rootPos
        val dist = delta.length()
        val maxReach = len1 + len2 - 0.001f
        val clampedDist = dist.coerceIn(0.001f, maxReach)
        val reached = dist <= maxReach

        // Direction from root to (clamped) target in world space.
        val dir = if (dist < 0.001f) Vec2.UP else (delta / dist)
        val clampedTarget = rootPos + dir * clampedDist
        val d2 = (clampedTarget - rootPos)

        // Law of cosines for the triangle (root, joint2, target).
        val a1 = ((len1 * len1 + clampedDist * clampedDist - len2 * len2) /
                (2f * len1 * clampedDist)).coerceIn(-1f, 1f)
        val joint1Angle = acos(a1) // angle at root between bone1 and line-to-target

        val a2 = ((len1 * len1 + len2 * len2 - clampedDist * clampedDist) /
                (2f * len1 * len2)).coerceIn(-1f, 1f)
        val joint2Interior = acos(a2) // interior angle at joint2 (elbow/knee)
        val angle2Rel = -(PI_F - joint2Interior) // relative bend of bone2 vs bone1

        // Direction angle measured from +y axis. Our rotate() is CCW-positive,
        // so a vector toward +x corresponds to a NEGATIVE angle — hence the
        // minus sign on atan2(x, y).
        val targetAngleFromY = -atan2(d2.x.toDouble(), d2.y.toDouble()).toFloat()

        val sign = if (bendSign >= 0f) 1f else -1f
        val worldAngle1 = targetAngleFromY + sign * joint1Angle
        // angle2Rel already encodes bend; apply same sign convention.
        val worldAngle2 = worldAngle1 + sign * angle2Rel

        val local1 = normalizeAngle(worldAngle1 - parentWorldAngle)
        val local2 = normalizeAngle(worldAngle2 - worldAngle1)
        return Solution(local1, local2, reached)
    }

    private const val PI_F = kotlin.math.PI.toFloat()

    /** Find the nearest joint to [p] within [radius], or null if none. */
    fun hitTest(positions: Map<JointId, Vec2>, p: Vec2, radius: Float): JointId? {
        var best: JointId? = null
        var bestD = radius * radius
        for ((j, pos) in positions) {
            val d = (pos - p).lengthSquared()
            if (d < bestD) { bestD = d; best = j }
        }
        return best
    }
}
