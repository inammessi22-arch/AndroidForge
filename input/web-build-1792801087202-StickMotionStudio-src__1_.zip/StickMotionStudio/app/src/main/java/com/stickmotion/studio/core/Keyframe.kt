package com.stickmotion.studio.core

/**
 * One keyframe on a character's track: the pose at an integer frame, with
 * the easing curve used to interpolate INTO the following segment.
 */
data class Keyframe(
    val frame: Int,
    val pose: Pose,
    val easing: Easing = Easing.EASE_IN_OUT
) {
    init {
        require(frame >= 0) { "Keyframe frame must be >= 0, was $frame" }
    }
}

/**
 * A single character's animation track: keyframes sorted ascending by frame.
 * Immutable; all operations return a new Track (supports undo/redo trivially).
 */
data class Track(val keyframes: List<Keyframe> = emptyList()) {

    init {
        require(keyframes == keyframes.sortedBy { it.frame }) { "Keyframes must be sorted by frame" }
        require(keyframes.map { it.frame }.distinct().size == keyframes.size) { "Duplicate keyframe frames" }
    }

    val isEmpty: Boolean get() = keyframes.isEmpty()
    val firstFrame: Int get() = keyframes.first().frame
    val lastFrame: Int get() = keyframes.last().frame

    fun withKeyframe(kf: Keyframe): Track =
        Track((keyframes.filterNot { it.frame == kf.frame } + kf).sortedBy { it.frame })

    fun removeKeyframeAt(frame: Int): Track =
        Track(keyframes.filterNot { it.frame == frame })

    fun moveKeyframe(from: Int, to: Int): Track {
        val kf = keyframes.firstOrNull { it.frame == from } ?: return this
        return withKeyframe(kf.copy(frame = to)).removeKeyframeAt(from)
    }

    /** Pose at (possibly fractional) frame. Holds at the ends. */
    fun poseAt(frame: Float): Pose {
        if (keyframes.isEmpty()) return Pose.neutral()
        if (frame <= keyframes.first().frame) return keyframes.first().pose
        if (frame >= keyframes.last().frame) return keyframes.last().pose
        // Find surrounding pair.
        var i = 0
        while (i < keyframes.size - 1 && keyframes[i + 1].frame < frame) i++
        val a = keyframes[i]
        val b = keyframes[i + 1]
        val span = (b.frame - a.frame).coerceAtLeast(1)
        val rawT = ((frame - a.frame) / span).coerceIn(0f, 1f)
        val t = a.easing.apply(rawT)
        return lerpPose(a.pose, b.pose, t)
    }

    /** True if a keyframe exists exactly at [frame]. */
    fun hasKeyframeAt(frame: Int): Boolean = keyframes.any { it.frame == frame }
}
