package com.stickmotion.studio.core

import kotlin.math.PI

/**
 * A single pose: root (hips) world position + one local rotation angle
 * (radians) per non-offset joint. Angle 0 means the bone points in the same
 * direction as its parent (for the spine, straight up).
 *
 * Pure data; forward kinematics are computed by [ForwardKinematics].
 */
data class Pose(
    val root: Vec2,
    val angles: Map<JointId, Float>
) {
    fun angleOf(joint: JointId): Float = angles[joint] ?: 0f

    fun withAngle(joint: JointId, angle: Float): Pose =
        copy(angles = angles + (joint to normalizeAngle(angle)))

    fun withRoot(pos: Vec2): Pose = copy(root = pos)

    fun deepCopy(): Pose = copy(angles = angles.toMap())

    companion object {
        /** Neutral standing pose, feet near y=0, hips at ~180 units up. */
        fun neutral(root: Vec2 = vec2(0f, 180f)): Pose {
            val a = mutableMapOf<JointId, Float>()
            // Spine straight up.
            a[JointId.CHEST] = 0f
            a[JointId.NECK] = 0f
            a[JointId.HEAD] = 0f
            // Arms hang down slightly out to the sides.
            a[JointId.L_ELBOW] = 0f; a[JointId.L_WRIST] = 0f
            a[JointId.R_ELBOW] = 0f; a[JointId.R_WRIST] = 0f
            a[JointId.L_SHOULDER] = deg(200f)  // down-and-out from shoulder
            a[JointId.R_SHOULDER] = deg(160f)
            // Legs straight down, slightly apart.
            a[JointId.L_KNEE] = 0f; a[JointId.L_ANKLE] = 0f
            a[JointId.R_KNEE] = 0f; a[JointId.R_ANKLE] = 0f
            a[JointId.L_HIP] = deg(180f + 8f)
            a[JointId.R_HIP] = deg(180f - 8f)
            return Pose(root, a)
        }
    }
}

fun deg(d: Float): Float = d * PI.toFloat() / 180f
fun toDeg(r: Float): Float = r * 180f / PI.toFloat()

/** Wrap angle into (-PI, PI]. */
fun normalizeAngle(a: Float): Float {
    var r = a
    while (r > PI) r -= (2 * PI).toFloat()
    while (r <= -PI) r += (2 * PI).toFloat()
    return r
}

/** Shortest-path angular interpolation, output in (-PI, PI]. */
fun lerpAngle(a: Float, b: Float, t: Float): Float {
    val d = normalizeAngle(b - a)
    return normalizeAngle(a + d * t)
}

/** Interpolate two poses. Root is linear, angles use shortest-path lerp. */
fun lerpPose(a: Pose, b: Pose, t: Float): Pose {
    val angles = mutableMapOf<JointId, Float>()
    for (j in JointId.ALL) {
        if (j == JointId.HIPS) continue
        angles[j] = lerpAngle(a.angleOf(j), b.angleOf(j), t)
    }
    return Pose(lerp(a.root, b.root, t), angles)
}
