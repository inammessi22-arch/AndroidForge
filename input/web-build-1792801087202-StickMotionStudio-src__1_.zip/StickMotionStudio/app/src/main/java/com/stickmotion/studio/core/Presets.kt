package com.stickmotion.studio.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Editable motion presets. Each generator returns a list of keyframes that
 * the user can apply to a character's track and then edit by hand. All math
 * is deterministic and unit-testable. Angles are in radians; the DOWN
 * reference for limbs is PI (pointing -y).
 */
object Presets {

    private val DOWN = PI.toFloat()
    private const val TWO_PI = (2 * PI).toFloat()

    enum class Id(val label: String) {
        WALK("Walk"), RUN("Run"), JUMP("Jump"), WAVE("Wave"),
        FALL("Fall"), PUNCH("Punch"), KICK("Kick"), DANCE("Dance")
    }

    fun generate(id: Id, base: Pose, cycleFrames: Int = 48): List<Keyframe> = when (id) {
        Id.WALK -> walk(base, cycleFrames, swing = 0.55f, bob = 6f, rootY = base.root.y)
        Id.RUN -> walk(base, cycleFrames, swing = 0.9f, bob = 14f, rootY = base.root.y - 14f)
        Id.JUMP -> jump(base, cycleFrames)
        Id.WAVE -> wave(base, cycleFrames)
        Id.FALL -> fall(base, cycleFrames)
        Id.PUNCH -> punch(base, cycleFrames)
        Id.KICK -> kick(base, cycleFrames)
        Id.DANCE -> dance(base, cycleFrames)
    }

    private fun build(
        frames: IntProgression,
        easing: Easing = Easing.EASE_IN_OUT,
        poseAtPhase: (phase: Float) -> Pose
    ): List<Keyframe> {
        val last = frames.last
        return frames.map { f ->
            val phase = f.toFloat() / last
            Keyframe(f, poseAtPhase(phase), easing)
        }
    }

    private fun Pose.mutate(block: (MutableMap<JointId, Float>) -> Unit): Pose {
        val a = angles.toMutableMap()
        block(a)
        return copy(angles = a)
    }

    private fun eightSteps(cycle: Int) = (0..cycle step (cycle / 8).coerceAtLeast(1))

    private fun walk(base: Pose, cycle: Int, swing: Float, bob: Float, rootY: Float): List<Keyframe> {
        return build(eightSteps(cycle)) { phase ->
            val s = phase * TWO_PI
            val legSwing = sin(s) * swing
            val armSwing = sin(s + PI.toFloat()) * swing * 0.9f
            val kneeBend = (0.5f + 0.5f * cos(s + PI.toFloat())) * 0.35f
            base.mutate { a ->
                a[JointId.L_HIP] = DOWN + legSwing
                a[JointId.R_HIP] = DOWN - legSwing
                a[JointId.L_KNEE] = kneeBend
                a[JointId.R_KNEE] = (0.5f + 0.5f * cos(s)) * 0.35f
                a[JointId.L_SHOULDER] = DOWN + armSwing // arms hang from shoulders, swing opposite legs
                a[JointId.R_SHOULDER] = DOWN - armSwing
                a[JointId.L_ELBOW] = 0.15f; a[JointId.R_ELBOW] = 0.15f
                a[JointId.CHEST] = sin(s) * 0.06f
            }.copy(root = vec2(base.root.x, rootY - bob * (0.5f + 0.5f * cos(2 * s)).toFloat()))
        }
    }

    private fun jump(base: Pose, cycle: Int): List<Keyframe> {
        val y0 = base.root.y
        return build((0..cycle step (cycle / 6).coerceAtLeast(1))) { phase ->
            when {
                phase < 0.2f -> { // crouch
                    val t = phase / 0.2f
                    base.mutate { a ->
                        a[JointId.L_KNEE] = deg(50f) * t; a[JointId.R_KNEE] = deg(50f) * t
                        a[JointId.L_HIP] = DOWN + deg(15f) * t; a[JointId.R_HIP] = DOWN - deg(15f) * t
                    }.copy(root = vec2(base.root.x, y0 - 40f * t))
                }
                phase < 0.5f -> { // launch + rise
                    val t = (phase - 0.2f) / 0.3f
                    val h = 140f * sin(t * PI.toFloat())
                    base.mutate { a ->
                        a[JointId.L_KNEE] = deg(30f) * (1 - t); a[JointId.R_KNEE] = deg(30f) * (1 - t)
                        a[JointId.L_SHOULDER] = deg(180f) - deg(160f) * t // arms up
                        a[JointId.R_SHOULDER] = deg(180f) + deg(160f) * t
                    }.copy(root = vec2(base.root.x, y0 + h))
                }
                else -> { // land + recover
                    val t = (phase - 0.5f) / 0.5f
                    base.mutate { a ->
                        a[JointId.L_KNEE] = deg(40f) * (1 - t); a[JointId.R_KNEE] = deg(40f) * (1 - t)
                    }.copy(root = vec2(base.root.x, y0 + 20f * (1 - t)))
                }
            }
        }
    }

    private fun wave(base: Pose, cycle: Int): List<Keyframe> =
        build(eightSteps(cycle)) { phase ->
            val s = phase * TWO_PI
            base.mutate { a ->
                a[JointId.R_SHOULDER] = deg(180f) - deg(150f) // arm raised (pointing up-ish)
                a[JointId.R_ELBOW] = deg(35f) + sin(s) * deg(30f) // forearm waves
                a[JointId.HEAD] = sin(s) * 0.08f
            }
        }

    private fun fall(base: Pose, cycle: Int): List<Keyframe> =
        build((0..cycle step (cycle / 6).coerceAtLeast(1))) { phase ->
            val t = phase
            base.mutate { a ->
                a[JointId.CHEST] = deg(80f) * t // torso pitches forward
                a[JointId.L_SHOULDER] = deg(200f) - deg(120f) * t
                a[JointId.R_SHOULDER] = deg(160f) + deg(120f) * t
                a[JointId.L_HIP] = DOWN + deg(20f) * t
                a[JointId.R_HIP] = DOWN - deg(20f) * t
            }.copy(root = vec2(base.root.x, base.root.y - 120f * t))
        }

    private fun punch(base: Pose, cycle: Int): List<Keyframe> =
        build((0..cycle step (cycle / 6).coerceAtLeast(1))) { phase ->
            val ext = when {
                phase < 0.3f -> phase / 0.3f // wind-up + extend
                phase < 0.6f -> 1f - (phase - 0.3f) / 0.3f * 0.3f // hold near full
                else -> (1f - (phase - 0.6f) / 0.4f) // retract
            }.coerceIn(0f, 1f)
            base.mutate { a ->
                a[JointId.R_SHOULDER] = deg(180f) - deg(90f) * ext // arm forward (horizontal)
                a[JointId.R_ELBOW] = deg(60f) * (1 - ext) // extends straight
                a[JointId.CHEST] = deg(10f) * ext
            }
        }

    private fun kick(base: Pose, cycle: Int): List<Keyframe> =
        build((0..cycle step (cycle / 6).coerceAtLeast(1))) { phase ->
            val ext = when {
                phase < 0.4f -> phase / 0.4f
                else -> (1f - (phase - 0.4f) / 0.6f).coerceIn(0f, 1f)
            }
            base.mutate { a ->
                a[JointId.R_HIP] = DOWN - deg(80f) * ext // leg raises forward
                a[JointId.R_KNEE] = deg(70f) * (1 - ext) // extends at impact
                a[JointId.CHEST] = -deg(15f) * ext // lean back
            }
        }

    private fun dance(base: Pose, cycle: Int): List<Keyframe> =
        build(eightSteps(cycle)) { phase ->
            val s = phase * TWO_PI
            base.mutate { a ->
                a[JointId.L_SHOULDER] = deg(180f) - deg(60f) * (0.5f + 0.5f * sin(s))
                a[JointId.R_SHOULDER] = deg(180f) + deg(60f) * (0.5f + 0.5f * sin(s + PI.toFloat()))
                a[JointId.L_ELBOW] = deg(40f); a[JointId.R_ELBOW] = deg(40f)
                a[JointId.CHEST] = sin(s) * 0.1f
                a[JointId.HEAD] = sin(2 * s).toFloat() * 0.12f
            }.copy(root = vec2(base.root.x + sin(s) * 30f, base.root.y + (0.5f + 0.5f * cos(2 * s)).toFloat() * 10f))
        }
}
