package com.stickmotion.studio.core

/**
 * Root editable project. Pure data — no Android references — so it can be
 * serialized, diffed, and unit-tested on the JVM.
 */
data class Project(
    val id: String,
    val name: String,
    val fps: Int = 24,
    val durationFrames: Int = 96, // 4s @ 24fps default
    val stageWidth: Int = 720,
    val stageHeight: Int = 1280,
    val background: Background = Background(),
    val characters: List<Character> = emptyList(),
    val audioTracks: List<AudioTrack> = emptyList(),
    val loop: Boolean = true,
    val version: Int = CURRENT_VERSION
) {
    init {
        require(fps in 1..60) { "fps out of range: $fps" }
        require(durationFrames >= 1) { "durationFrames must be >= 1" }
        require(stageWidth in 160..4096 && stageHeight in 160..4096) { "stage size out of range" }
    }

    val durationSeconds: Float get() = durationFrames.toFloat() / fps

    fun characterById(id: String): Character? = characters.firstOrNull { it.id == id }

    fun updateCharacter(id: String, transform: (Character) -> Character): Project =
        copy(characters = characters.map { if (it.id == id) transform(it) else it })

    fun addCharacter(c: Character): Project = copy(characters = characters + c)
    fun removeCharacter(id: String): Project = copy(characters = characters.filterNot { it.id == id })

    fun withKeyframe(characterId: String, kf: Keyframe): Project = updateCharacter(characterId) {
        it.withTrack(it.track.withKeyframe(kf))
    }

    fun removeKeyframe(characterId: String, frame: Int): Project = updateCharacter(characterId) {
        it.withTrack(it.track.removeKeyframeAt(frame))
    }

    companion object {
        const val CURRENT_VERSION = 1

        fun newEmpty(name: String): Project {
            val id = "proj_${System.nanoTime()}"
            val char = Character(
                id = Character.newId(),
                name = "Stickman",
                config = StickmanConfig(),
                track = Track(listOf(Keyframe(0, Pose.neutral(root = vec2(360f, 420f)))))
            )
            return Project(id = id, name = name, characters = listOf(char))
        }
    }
}
