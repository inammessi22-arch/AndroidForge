package com.stickmotion.studio.core

/**
 * Joint identifiers for the stickman skeleton.
 *
 * Hierarchy (parent -> child):
 *   HIPS (root)
 *     +-> CHEST -> NECK -> HEAD
 *     +-> L_HIP  -> L_KNEE -> L_ANKLE
 *     +-> R_HIP  -> R_KNEE -> R_ANKLE
 *     +-> L_SHOULDER (attached at CHEST) -> L_ELBOW -> L_WRIST
 *     +-> R_SHOULDER (attached at CHEST) -> R_ELBOW -> R_WRIST
 *
 * Every non-root joint is the END of a bone whose START is its parent.
 * A Pose stores one local rotation angle per joint (the rotation of that
 * joint's bone relative to the parent bone) plus the root world position.
 */
enum class JointId(val parent: JointId?, val label: String) {
    HIPS(null, "Hips"),
    CHEST(HIPS, "Torso"),
    NECK(CHEST, "Neck"),
    HEAD(NECK, "Head"),
    L_HIP(HIPS, "Left Hip"),
    L_KNEE(L_HIP, "Left Knee"),
    L_ANKLE(L_KNEE, "Left Ankle"),
    R_HIP(HIPS, "Right Hip"),
    R_KNEE(R_HIP, "Right Knee"),
    R_ANKLE(R_KNEE, "Right Ankle"),
    L_SHOULDER(CHEST, "Left Shoulder"),
    L_ELBOW(L_SHOULDER, "Left Elbow"),
    L_WRIST(L_ELBOW, "Left Wrist"),
    R_SHOULDER(CHEST, "Right Shoulder"),
    R_ELBOW(R_SHOULDER, "Right Elbow"),
    R_WRIST(R_ELBOW, "Right Wrist");

    val isRoot: Boolean get() = parent == null

    /** Chain from this joint up to (and including) the root. */
    fun chain(): List<JointId> {
        val out = mutableListOf<JointId>()
        var j: JointId? = this
        while (j != null) {
            out.add(j)
            j = j.parent
        }
        return out
    }

    companion object {
        val ALL = entries.toList()
        val DRAGGABLE = ALL.filter { it != HIPS } // hips moved by translating the root
    }
}

/**
 * Fixed proportions of a stickman. Lengths are in canvas units (pixels at
 * 720p reference; the renderer scales uniformly). All values are editable
 * per-character so beginners can make tall/short/stout figures.
 */
data class StickmanConfig(
    val torsoLength: Float = 110f,   // hips -> chest
    val neckLength: Float = 22f,     // chest -> neck
    val headRadius: Float = 26f,     // head circle radius (neck -> head center = radius)
    val upperArm: Float = 72f,       // shoulder -> elbow
    val foreArm: Float = 66f,        // elbow -> wrist
    val upperLeg: Float = 92f,       // hip -> knee
    val lowerLeg: Float = 88f,       // knee -> ankle
    val shoulderWidth: Float = 44f,  // half-distance between shoulders at chest
    val hipWidth: Float = 30f,       // half-distance between leg hips at root
    val strokeWidth: Float = 9f,
    val colorArgb: Int = 0xFFE8EAED.toInt() // light stick on dark stage
) {
    /** Bone length for the bone that ENDS at [joint]. */
    fun lengthOf(joint: JointId): Float = when (joint) {
        JointId.CHEST -> torsoLength
        JointId.NECK -> neckLength
        JointId.HEAD -> headRadius
        JointId.L_SHOULDER, JointId.R_SHOULDER -> 0f // offset joint, no bone length
        JointId.L_ELBOW, JointId.R_ELBOW -> upperArm
        JointId.L_WRIST, JointId.R_WRIST -> foreArm
        JointId.L_KNEE, JointId.R_KNEE -> upperLeg
        JointId.L_ANKLE, JointId.R_ANKLE -> lowerLeg
        JointId.L_HIP, JointId.R_HIP -> 0f // offset joint
        JointId.HIPS -> 0f
    }

    /**
     * Lateral offset (perpendicular to parent bone direction) applied to
     * offset joints (shoulders, hips) so the figure has width. Positive =
     * character's left.
     */
    fun lateralOffsetOf(joint: JointId): Float = when (joint) {
        JointId.L_SHOULDER -> shoulderWidth
        JointId.R_SHOULDER -> -shoulderWidth
        JointId.L_HIP -> hipWidth
        JointId.R_HIP -> -hipWidth
        else -> 0f
    }
}
