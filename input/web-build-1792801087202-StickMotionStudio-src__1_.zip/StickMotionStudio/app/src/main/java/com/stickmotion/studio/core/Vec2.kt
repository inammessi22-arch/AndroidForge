package com.stickmotion.studio.core

import kotlin.math.sqrt

/**
 * Immutable 2D vector in "math" coordinates (y points up).
 * The renderer flips y to screen coordinates at draw time.
 * Pure Kotlin — no Android dependencies, unit-testable on the JVM.
 */
@JvmInline
value class Vec2(val packed: Long) {
    val x: Float get() = Float.fromBits((packed ushr 32).toInt())
    val y: Float get() = Float.fromBits(packed.toInt())

    operator fun plus(o: Vec2) = vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = vec2(x * s, y * s)
    operator fun div(s: Float) = vec2(x / s, y / s)
    operator fun unaryMinus() = vec2(-x, -y)

    fun length(): Float = sqrt((x * x + y * y).toDouble()).toFloat()
    fun lengthSquared(): Float = x * x + y * y
    fun normalized(): Vec2 {
        val l = length()
        return if (l < 1e-6f) ZERO else this / l
    }

    fun distanceTo(o: Vec2): Float = (this - o).length()
    fun dot(o: Vec2): Float = x * o.x + y * o.y

    companion object {
        val ZERO = vec2(0f, 0f)
        val UP = vec2(0f, 1f)
        val DOWN = vec2(0f, -1f)
    }
}

fun vec2(x: Float, y: Float): Vec2 {
    val xl = x.toRawBits().toLong() and 0xFFFFFFFFL
    val yl = y.toRawBits().toLong() and 0xFFFFFFFFL
    return Vec2((xl shl 32) or yl)
}

/** Rotate by angle (radians) around the origin. */
fun Vec2.rotate(angle: Float): Vec2 {
    val c = kotlin.math.cos(angle)
    val s = kotlin.math.sin(angle)
    return vec2(x * c - y * s, x * s + y * c)
}

fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
fun lerp(a: Vec2, b: Vec2, t: Float): Vec2 = vec2(lerp(a.x, b.x, t), lerp(a.y, b.y, t))
