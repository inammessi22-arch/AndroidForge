package com.stickmotion.studio.data

import android.content.Context
import android.net.Uri
import com.stickmotion.studio.core.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Local-first project storage. Every project is one validated JSON file under
 * filesDir/projects. No cloud, no account. Autosave is driven by the editor
 * ViewModel (debounced); this class only does atomic writes.
 */
class ProjectRepository(context: Context) {

    private val dir = File(context.filesDir, "projects").apply { mkdirs() }
    private val resolver = context.contentResolver

    data class Summary(val id: String, val name: String, val modifiedMs: Long, val sizeBytes: Long)

    suspend fun listSummaries(): List<Summary> = withContext(Dispatchers.IO) {
        dir.listFiles { f -> f.name.endsWith(".sms.json") }?.mapNotNull { f ->
            try {
                val p = load(f.nameWithoutExtension.removeSuffix(".sms")) ?: return@mapNotNull null
                Summary(p.id, p.name, f.lastModified(), f.length())
            } catch (_: Exception) { null }
        }?.sortedByDescending { it.modifiedMs } ?: emptyList()
    }

    suspend fun save(project: Project): Unit = withContext(Dispatchers.IO) {
        val tmp = File(dir, "${project.id}.tmp")
        tmp.writeText(ProjectSerializer.encode(project))
        val target = File(dir, "${project.id}.sms.json")
        if (!tmp.renameTo(target)) {
            // Fallback: copy then delete (rename fails across some mount points).
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
    }

    suspend fun load(id: String): Project? = withContext(Dispatchers.IO) {
        val f = File(dir, "$id.sms.json")
        if (!f.exists()) return@withContext null
        ProjectSerializer.decodeValidated(f.readText()).getOrNull()
    }

    suspend fun delete(id: String): Unit = withContext(Dispatchers.IO) {
        File(dir, "$id.sms.json").delete()
    }

    suspend fun rename(id: String, newName: String): Project? {
        val p = load(id) ?: return null
        val renamed = p.copy(name = newName)
        save(renamed)
        return renamed
    }

    suspend fun duplicate(id: String): Project? {
        val p = load(id) ?: return null
        val copy = p.copy(id = "proj_${System.nanoTime()}", name = "${p.name} (copy)")
        save(copy)
        return copy
    }

    /** Import a .sms.json from a SAF Uri. Validates before saving. */
    suspend fun importFromUri(uri: Uri): Result<Project> = withContext(Dispatchers.IO) {
        try {
            val text = resolver.openInputStream(uri)?.bufferedReader()?.readText()
                ?: return@withContext Result.failure(Exception("Could not read file."))
            val decoded = ProjectSerializer.decodeValidated(text)
            decoded.onSuccess { p ->
                val fresh = p.copy(id = "proj_${System.nanoTime()}", name = "${p.name} (imported)")
                save(fresh)
                return@withContext Result.success(fresh)
            }
            decoded
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Export a project JSON to a user-chosen SAF Uri. */
    suspend fun exportToUri(project: Project, uri: Uri): Unit = withContext(Dispatchers.IO) {
        resolver.openOutputStream(uri)?.use { it.write(ProjectSerializer.encode(project).toByteArray()) }
            ?: throw Exception("Could not write to selected location.")
    }
}
