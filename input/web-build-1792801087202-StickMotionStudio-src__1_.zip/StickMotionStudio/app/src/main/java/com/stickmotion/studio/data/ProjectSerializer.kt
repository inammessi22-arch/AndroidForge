package com.stickmotion.studio.data

import com.stickmotion.studio.core.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * JSON project format (.sms.json). Domain objects are mapped to/from these
 * serializable DTOs so the domain model stays framework-free.
 *
 * Import is always validated: [decodeValidated] returns either a Project or
 * a non-empty list of human-readable errors. Never trust an imported file.
 */
private val JSON = Json {
    prettyPrint = true
    ignoreUnknownKeys = true
    encodeDefaults = true
}

@Serializable
private data class Vec2Dto(val x: Float, val y: Float)

@Serializable
private data class PoseDto(
    val rootX: Float, val rootY: Float,
    val anglesDeg: Map<String, Float>
)

@Serializable
private data class KeyframeDto(
    val frame: Int,
    val easing: String = "EASE_IN_OUT",
    val pose: PoseDto
)

@Serializable
private data class ConfigDto(
    val torsoLength: Float = 110f, val neckLength: Float = 22f,
    val headRadius: Float = 26f, val upperArm: Float = 72f,
    val foreArm: Float = 66f, val upperLeg: Float = 92f,
    val lowerLeg: Float = 88f, val shoulderWidth: Float = 44f,
    val hipWidth: Float = 30f, val strokeWidth: Float = 9f,
    val colorArgb: Long = 0xFFE8EAED
)

@Serializable
private data class CharacterDto(
    val id: String, val name: String,
    val config: ConfigDto,
    val keyframes: List<KeyframeDto>,
    val visible: Boolean = true, val layer: Int = 0
)

@Serializable
private data class AudioDto(
    val id: String, val sourceUri: String,
    val startFrame: Int = 0, val volume: Float = 1f,
    val name: String = "Audio"
)

@Serializable
private data class BackgroundDto(
    val colorArgb: Long = 0xFF1A1C1E,
    val imageUri: String? = null,
    val imageFit: String = "COVER"
)

@Serializable
private data class ProjectDto(
    val format: String = "stickmotion-studio",
    val version: Int = Project.CURRENT_VERSION,
    val id: String, val name: String,
    val fps: Int, val durationFrames: Int,
    val stageWidth: Int, val stageHeight: Int,
    val background: BackgroundDto,
    val characters: List<CharacterDto>,
    val audioTracks: List<AudioDto> = emptyList(),
    val loop: Boolean = true
)

object ProjectSerializer {

    fun encode(project: Project): String = JSON.encodeToString(project.toDto())

    /** @return Right(project) on success, Left(errors) on validation failure. */
    fun decodeValidated(text: String): Result<Project> {
        val dto = try {
            JSON.decodeFromString<ProjectDto>(text)
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException(
                "Not a valid StickMotion Studio project file: ${e.message}"))
        }
        val errors = validate(dto)
        if (errors.isNotEmpty()) {
            return Result.failure(IllegalArgumentException(
                "Project validation failed:\n" + errors.joinToString("\n") { " - $it" }))
        }
        return Result.success(dto.toDomain())
    }

    /** Validation rules — applied to every imported file before acceptance. */
    private fun validate(dto: ProjectDto): List<String> {
        val e = mutableListOf<String>()
        if (dto.format != "stickmotion-studio") e.add("Unknown format '${dto.format}'.")
        if (dto.version !in 1..Project.CURRENT_VERSION)
            e.add("Unsupported project version ${dto.version}.")
        if (dto.fps !in 1..60) e.add("fps ${dto.fps} out of range (1..60).")
        if (dto.durationFrames < 1) e.add("durationFrames must be >= 1.")
        if (dto.stageWidth !in 160..4096 || dto.stageHeight !in 160..4096)
            e.add("Stage dimensions out of range (160..4096).")
        if (dto.characters.isEmpty()) e.add("Project has no characters.")
        for ((ci, c) in dto.characters.withIndex()) {
            val frames = c.keyframes.map { it.frame }
            if (frames != frames.sorted()) e.add("Character '${c.name}' keyframes not sorted.")
            if (frames.distinct().size != frames.size) e.add("Character '${c.name}' has duplicate keyframe frames.")
            if (frames.any { it < 0 }) e.add("Character '${c.name}' has negative keyframe frame.")
            if (c.keyframes.isEmpty()) e.add("Character '${c.name}' has no keyframes.")
            for (kf in c.keyframes) {
                if (kf.frame > dto.durationFrames)
                    e.add("Character '${c.name}' keyframe at frame ${kf.frame} exceeds duration ${dto.durationFrames}.")
                if (!Easing.entries.any { it.name == kf.easing })
                    e.add("Unknown easing '${kf.easing}' at frame ${kf.frame}.")
            }
            @Suppress("UNUSED_VARIABLE") val idx = ci
        }
        for (a in dto.audioTracks) {
            if (a.sourceUri.isBlank()) e.add("Audio track '${a.name}' has empty source.")
            if (a.startFrame < 0) e.add("Audio track '${a.name}' has negative startFrame.")
            if (a.volume !in 0f..1f) e.add("Audio track '${a.name}' volume out of range.")
        }
        return e
    }

    // ---- mapping ----

    private fun Pose.toDto() = PoseDto(
        rootX = root.x, rootY = root.y,
        anglesDeg = angles.mapKeys { it.key.name }.mapValues { toDeg(it.value).toFloat() }
    )

    private fun PoseDto.toDomain(): Pose {
        val angles = JointId.ALL.associateWith { j ->
            deg((anglesDeg[j.name] ?: 0f))
        }.filterKeys { it != JointId.HIPS }
        return Pose(vec2(rootX, rootY), angles)
    }

    private fun Keyframe.toDto() = KeyframeDto(frame, easing.name, pose.toDto())

    private fun KeyframeDto.toDomain() = Keyframe(
        frame = frame,
        easing = Easing.entries.firstOrNull { it.name == easing } ?: Easing.EASE_IN_OUT,
        pose = pose.toDomain()
    )

    private fun ConfigDto.toDomain() = StickmanConfig(
        torsoLength, neckLength, headRadius, upperArm, foreArm, upperLeg, lowerLeg,
        shoulderWidth, hipWidth, strokeWidth, colorArgb.toInt()
    )

    private fun StickmanConfig.toDto() = ConfigDto(
        torsoLength, neckLength, headRadius, upperArm, foreArm, upperLeg, lowerLeg,
        shoulderWidth, hipWidth, strokeWidth, colorArgb.toLong() and 0xFFFFFFFFL
    )

    private fun Character.toDto() = CharacterDto(
        id, name, config.toDto(),
        track.keyframes.map { it.toDto() }, visible, layer
    )

    private fun CharacterDto.toDomain() = Character(
        id = id, name = name, config = config.toDomain(),
        track = Track(keyframes.map { it.toDomain() }),
        visible = visible, layer = layer
    )

    private fun AudioTrack.toDto() = AudioDto(id, sourceUri, startFrame, volume, name)
    private fun AudioDto.toDomain() = AudioTrack(id, sourceUri, startFrame, volume, name)

    private fun Background.toDto() = BackgroundDto(
        colorArgb.toLong() and 0xFFFFFFFFL, imageUri, imageFit.name
    )

    private fun BackgroundDto.toDomain() = Background(
        colorArgb.toInt(), imageUri,
        Background.Fit.entries.firstOrNull { it.name == imageFit } ?: Background.Fit.COVER
    )

    private fun Project.toDto() = ProjectDto(
        id = id, name = name, fps = fps, durationFrames = durationFrames,
        stageWidth = stageWidth, stageHeight = stageHeight,
        background = background.toDto(),
        characters = characters.map { it.toDto() },
        audioTracks = audioTracks.map { it.toDto() },
        loop = loop, version = version
    )

    private fun ProjectDto.toDomain() = Project(
        id = id, name = name, fps = fps, durationFrames = durationFrames,
        stageWidth = stageWidth, stageHeight = stageHeight,
        background = background.toDomain(),
        characters = characters.map { it.toDomain() },
        audioTracks = audioTracks.map { it.toDomain() },
        loop = loop, version = version
    )
}
