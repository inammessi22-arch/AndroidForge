package com.stickmotion.studio.render

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.stickmotion.studio.core.ExportConfig
import com.stickmotion.studio.core.Project
import com.stickmotion.studio.data.ProjectSerializer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * Foreground service that runs MP4 export so it survives screen-off and
 * process prioritization. Progress is published via [ExportState] which the
 * UI observes; cancellation is cooperative (cancel -> job.cancel()).
 */
class ExportService : Service() {

    private val scope = CoroutineScope(Job() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val projectJson = intent.getStringExtra(EXTRA_PROJECT_JSON) ?: return START_NOT_STICKY
                val outputUri = intent.getParcelableExtra<Uri>(EXTRA_OUTPUT_URI)
                    ?: return START_NOT_STICKY
                val config = ExportConfig(
                    width = intent.getIntExtra(EXTRA_W, 720),
                    height = intent.getIntExtra(EXTRA_H, 1280),
                    fps = intent.getIntExtra(EXTRA_FPS, 24),
                    includeAudio = intent.getBooleanExtra(EXTRA_AUDIO, true)
                )
                val project = ProjectSerializer.decodeValidated(projectJson).getOrElse {
                    ExportState.onFailure("Project data corrupted: ${it.message}")
                    stopSelf(); return START_NOT_STICKY
                }
                startForeground(NOTIF_ID, buildNotification(0, project.durationFrames))
                job = scope.launch {
                    ExportState.onStart()
                    try {
                        Mp4Exporter(this@ExportService).export(project, config, outputUri) { done, total ->
                            ExportState.onProgress(done, total)
                            notify(done, total)
                        }
                        ExportState.onSuccess(outputUri)
                    } catch (e: Exception) {
                        ExportState.onFailure(e.message ?: "Export failed")
                    } finally {
                        stopSelf()
                    }
                }
            }
            ACTION_CANCEL -> {
                job?.cancel()
                ExportState.onCancelled()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun notify(done: Int, total: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(done, total))
    }

    private fun buildNotification(done: Int, total: Int): Notification {
        ensureChannel()
        val cancelIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ExportService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rendering MP4")
            .setContentText("$done / $total frames")
            .setSmallIcon(android.R.drawable.ic_menu_slideshow)
            .setProgress(total, done, false)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelIntent)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Video export", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.stickmotion.studio.EXPORT_START"
        const val ACTION_CANCEL = "com.stickmotion.studio.EXPORT_CANCEL"
        const val EXTRA_PROJECT_JSON = "project_json"
        const val EXTRA_OUTPUT_URI = "output_uri"
        const val EXTRA_W = "w"; const val EXTRA_H = "h"; const val EXTRA_FPS = "fps"; const val EXTRA_AUDIO = "audio"
        private const val CHANNEL_ID = "export_channel"
        private const val NOTIF_ID = 1001

        fun start(context: Context, project: Project, config: ExportConfig, outputUri: Uri) {
            val intent = Intent(context, ExportService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PROJECT_JSON, ProjectSerializer.encode(project))
                putExtra(EXTRA_OUTPUT_URI, outputUri)
                putExtra(EXTRA_W, config.width); putExtra(EXTRA_H, config.height)
                putExtra(EXTRA_FPS, config.fps); putExtra(EXTRA_AUDIO, config.includeAudio)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun cancel(context: Context) {
            context.startService(Intent(context, ExportService::class.java).setAction(ACTION_CANCEL))
        }
    }
}

/** Observable export state shared between the service and the UI. */
object ExportState {
    sealed class Status {
        data object Idle : Status()
        data class Running(val done: Int, val total: Int) : Status()
        data class Success(val outputUri: Uri) : Status()
        data class Failed(val message: String) : Status()
        data object Cancelled : Status()
    }
    private val _state = MutableStateFlow<Status>(Status.Idle)
    val state: StateFlow<Status> = _state
    fun onStart() { _state.value = Status.Running(0, 1) }
    fun onProgress(done: Int, total: Int) { _state.value = Status.Running(done, total) }
    fun onSuccess(uri: Uri) { _state.value = Status.Success(uri) }
    fun onFailure(msg: String) { _state.value = Status.Failed(msg) }
    fun onCancelled() { _state.value = Status.Cancelled }
}
