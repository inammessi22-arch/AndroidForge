package com.stickmotion.studio.render

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.stickmotion.studio.core.ExportConfig
import com.stickmotion.studio.core.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.coroutines.coroutineContext

/**
 * Genuine MP4 export using only Android framework APIs (Apache-2.0 licensed):
 * MediaCodec AVC encoder + input Surface + MediaMuxer. Each animation frame
 * is drawn to the encoder's input Surface with the same [SceneRenderer] used
 * in the editor, so what you see is what you export.
 *
 * Audio: best-effort passthrough mux of the first audio track's compressed
 * stream (works for AAC/MP3/AMR supported by MediaMuxer). If audio muxing
 * fails, the video is still exported and [ExportResult.audioMuxed] is false.
 *
 * Errors are thrown as [ExportException] with a user-readable message; the
 * caller (ExportService) maps them to notifications. Cancellation is
 * cooperative via the coroutine Job.
 */
class Mp4Exporter(private val context: Context) {

    data class ExportResult(val frames: Int, val audioMuxed: Boolean)
    class ExportException(message: String, cause: Throwable? = null) : Exception(message, cause)

    suspend fun export(
        project: Project,
        config: ExportConfig,
        outputUri: Uri,
        onProgress: (Int, Int) -> Unit
    ): ExportResult = withContext(Dispatchers.IO) {
        val width = config.width
        val height = config.height
        val fps = config.fps.coerceIn(1, 60)
        val totalFrames = project.durationFrames
        val bitrate = (width * height * fps * 0.12f).toInt().coerceAtLeast(1_500_000)

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }

        val encoder = try {
            MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        } catch (e: Exception) {
            throw ExportException("This device does not support AVC video encoding.", e)
        }
        var muxer: MediaMuxer? = null
        var pfd: ParcelFileDescriptor? = null
        var videoTrackIndex = -1
        var muxerStarted = false
        var framesEncoded = 0

        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = encoder.createInputSurface()
            encoder.start()

            pfd = context.contentResolver.openFileDescriptor(outputUri, "w")
                ?: throw ExportException("Could not open output file for writing.")
            muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val bgBitmap = project.background.imageUri?.let { uri ->
                try {
                    context.contentResolver.openInputStream(Uri.parse(uri))?.use {
                        BitmapFactory.decodeStream(it)
                    }
                } catch (_: Exception) { null }
            }

            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var frame = 0

            while (!inputDone) {
                coroutineContext.ensureActive() // cooperative cancellation
                if (frame < totalFrames) {
                    val canvas = inputSurface.lockCanvas(null)
                    try {
                        SceneRenderer.draw(
                            canvas, project, frame.toFloat(), width, height,
                            showHandles = false, backgroundBitmap = bgBitmap
                        )
                    } finally {
                        inputSurface.unlockCanvasAndPost(canvas)
                    }
                    frame++
                } else {
                    encoder.signalEndOfInputStream()
                    inputDone = true
                }

                // Drain encoder output.
                var eos = false
                while (!eos) {
                    val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10_000)
                    when {
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (muxerStarted) throw ExportException("Format changed twice.")
                            videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                        outIndex == MediaCodec.INFO_TRY_AGAIN_LATER -> eos = true
                        outIndex >= 0 -> {
                            val encoded = encoder.getOutputBuffer(outIndex)!!
                            if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                                bufferInfo.size = 0
                            }
                            if (bufferInfo.size > 0) {
                                if (!muxerStarted) throw ExportException("Muxer not started.")
                                bufferInfo.presentationTimeUs = (framesEncoded * 1_000_000L / fps)
                                encoded.position(bufferInfo.offset)
                                encoded.limit(bufferInfo.offset + bufferInfo.size)
                                muxer.writeSampleData(videoTrackIndex, encoded, bufferInfo)
                            }
                            val isEos = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            encoder.releaseOutputBuffer(outIndex, false)
                            if (isEos) { inputDone = true; eos = true }
                            framesEncoded++
                            onProgress(framesEncoded.coerceAtMost(totalFrames), totalFrames)
                        }
                    }
                }
            }

            var audioMuxed = false
            if (config.includeAudio && project.audioTracks.isNotEmpty()) {
                audioMuxed = try {
                    muxAudioTrack(muxer, project, fps)
                    true
                } catch (_: Exception) {
                    false // video already written; continue without audio
                }
            }
            return@withContext ExportResult(framesEncoded, audioMuxed)
        } catch (e: Exception) {
            if (e is ExportException) throw e
            throw ExportException("Export failed: ${e.message}", e)
        } finally {
            try { encoder.stop() } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
            try { muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Passthrough-mux an audio track's compressed frames. Only supports
     * formats MediaMuxer can write (AAC, MP3 on API 29+, AMR). Timestamps are
     * shifted by the track's start frame.
     */
    private fun muxAudioTrack(muxer: MediaMuxer, project: Project, fps: Int) {
        val track = project.audioTracks.first()
        val extractor = android.media.MediaExtractor()
        context.contentResolver.openFileDescriptor(android.net.Uri.parse(track.sourceUri), "r")
            ?.let { extractor.setDataSource(it.fileDescriptor) }
            ?: return
        var audioTrackIndex = -1
        for (i in 0 until extractor.trackCount) {
            val fmt = extractor.getTrackFormat(i)
            if (fmt.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                extractor.selectTrack(i)
                audioTrackIndex = muxer.addTrack(fmt)
                break
            }
        }
        if (audioTrackIndex < 0) { extractor.release(); return }
        val offsetUs = (track.startFrame * 1_000_000L / fps)
        val info = MediaCodec.BufferInfo()
        val buf = ByteBuffer.allocate(256 * 1024)
        while (true) {
            val size = extractor.readSampleData(buf, 0)
            if (size < 0) break
            info.offset = 0
            info.size = size
            info.presentationTimeUs = extractor.sampleTime + offsetUs
            info.flags = if (extractor.sampleFlags and android.media.MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                MediaCodec.BUFFER_FLAG_SYNC_FRAME else 0
            muxer.writeSampleData(audioTrackIndex, buf, info)
            extractor.advance()
        }
        extractor.release()
    }
}
