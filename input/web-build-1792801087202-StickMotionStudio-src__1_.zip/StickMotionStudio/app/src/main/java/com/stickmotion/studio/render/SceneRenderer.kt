package com.stickmotion.studio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.stickmotion.studio.core.Background
import com.stickmotion.studio.core.Character
import com.stickmotion.studio.core.ForwardKinematics
import com.stickmotion.studio.core.JointId
import com.stickmotion.studio.core.Project
import com.stickmotion.studio.core.Vec2
import com.stickmotion.studio.core.vec2

/**
 * Renders a [Project] at a given frame to an Android [Canvas]. Used by both
 * the interactive Compose stage and the offline MP4 encoder, so it is
 * deterministic and side-effect free.
 *
 * Coordinate convention: the project stage is defined in math coordinates
 * (y up). We flip the canvas so the same [ForwardKinematics] output draws
 * upright.
 */
object SceneRenderer {

    data class HandlePositions(val positions: Map<JointId, Vec2>, val scale: Float)

    /**
     * @param showHandles if true, draws draggable joint circles (editor mode).
     * @param selectedJoint highlighted handle, or null.
     * @param backgroundBitmap decoded [Background.imageUri], or null.
     */
    fun draw(
        canvas: Canvas,
        project: Project,
        frame: Float,
        viewWidth: Int,
        viewHeight: Int,
        showHandles: Boolean = false,
        selectedJoint: JointId? = null,
        selectedCharacterId: String? = null,
        backgroundBitmap: Bitmap? = null
    ): HandlePositions? {
        val stageW = project.stageWidth.toFloat()
        val stageH = project.stageHeight.toFloat()
        val scale = minOf(viewWidth / stageW, viewHeight / stageH)
        val offsetX = (viewWidth - stageW * scale) / 2f
        val offsetY = (viewHeight - stageH * scale) / 2f

        // Background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = project.background.colorArgb }
        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), bgPaint)
        backgroundBitmap?.let { bmp ->
            drawBackgroundImage(canvas, bmp, project.background, viewWidth, viewHeight)
        }

        var handlePositions: Map<JointId, Vec2>? = null
        var handleScale = scale

        canvas.save()
        // Flip y: translate to bottom of letterbox then scale y by -scale.
        canvas.translate(offsetX, offsetY + stageH * scale)
        canvas.scale(scale, -scale)

        val characters = project.characters.filter { it.visible }.sortedBy { it.layer }
        for (ch in characters) {
            val pose = ch.poseAt(frame)
            val fk = ForwardKinematics.solve(pose, ch.config)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ch.config.colorArgb
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            for (bone in fk.bones) {
                paint.strokeWidth = bone.width
                canvas.drawLine(bone.from.x, bone.from.y, bone.to.x, bone.to.y, paint)
            }
            // Head
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = ch.config.strokeWidth
            canvas.drawCircle(fk.headCenter.x, fk.headCenter.y, fk.headRadius, paint)
            // Eyes (two dots) so the figure has a facing direction.
            paint.style = Paint.Style.FILL
            val eyeY = fk.headCenter.y + fk.headRadius * 0.15f
            canvas.drawCircle(fk.headCenter.x - fk.headRadius * 0.35f, eyeY, fk.headRadius * 0.12f, paint)
            canvas.drawCircle(fk.headCenter.x + fk.headRadius * 0.35f, eyeY, fk.headRadius * 0.12f, paint)

            if (showHandles && ch.id == selectedCharacterId) {
                handlePositions = fk.positions
                handleScale = scale
            }
        }
        canvas.restore()

        if (showHandles && handlePositions != null) {
            drawHandles(canvas, handlePositions, offsetX, offsetY, scale, stageH, selectedJoint)
        }
        return handlePositions?.let { HandlePositions(it, handleScale) }
    }

    /** Handles are drawn in screen space (no flip) so they stay circular and tappable. */
    private fun drawHandles(
        canvas: Canvas,
        positions: Map<JointId, Vec2>,
        offsetX: Float,
        offsetY: Float,
        scale: Float,
        stageH: Float,
        selected: JointId?
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        for ((j, p) in positions) {
            val sx = offsetX + p.x * scale
            val sy = offsetY + (stageH - p.y) * scale // flip y back to screen
            val r = if (j == selected) 14f else 10f
            paint.style = Paint.Style.FILL
            paint.color = if (j == selected) 0xFFFFB300.toInt() else 0x80FFFFFF.toInt()
            canvas.drawCircle(sx, sy, r, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = 0xFFFFFFFF.toInt()
            canvas.drawCircle(sx, sy, r, paint)
        }
    }

    private fun drawBackgroundImage(
        canvas: Canvas,
        bmp: Bitmap,
        bg: Background,
        vw: Int,
        vh: Int
    ) {
        val src = android.graphics.Rect(0, 0, bmp.width, bmp.height)
        val dst = when (bg.imageFit) {
            Background.Fit.STRETCH -> android.graphics.RectF(0f, 0f, vw.toFloat(), vh.toFloat())
            Background.Fit.COVER -> {
                val scale = maxOf(vw.toFloat() / bmp.width, vh.toFloat() / bmp.height)
                val w = bmp.width * scale
                val h = bmp.height * scale
                android.graphics.RectF((vw - w) / 2, (vh - h) / 2, (vw + w) / 2, (vh + h) / 2)
            }
            Background.Fit.CONTAIN -> {
                val scale = minOf(vw.toFloat() / bmp.width, vh.toFloat() / bmp.height)
                val w = bmp.width * scale
                val h = bmp.height * scale
                android.graphics.RectF((vw - w) / 2, (vh - h) / 2, (vw + w) / 2, (vh + h) / 2)
            }
        }
        canvas.drawBitmap(bmp, src, dst, Paint(Paint.FILTER_BITMAP_FLAG))
    }

    /** Clear helper for the encoder surface (transparent -> opaque bg covers it anyway). */
    fun clear(canvas: Canvas) {
        val p = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
        canvas.drawRect(0f, 0f, canvas.width.toFloat(), canvas.height.toFloat(), p)
    }
}
