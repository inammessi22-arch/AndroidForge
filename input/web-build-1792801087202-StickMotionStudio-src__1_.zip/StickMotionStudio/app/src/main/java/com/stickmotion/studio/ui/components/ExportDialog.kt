package com.stickmotion.studio.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.stickmotion.studio.core.ExportConfig
import com.stickmotion.studio.render.ExportState
import com.stickmotion.studio.viewmodel.EditorViewModel

/**
 * Export dialog: pick resolution/aspect preset + fps, choose output file via
 * SAF (no storage permission needed), then observe [ExportState] for
 * progress / success / failure. Cancellation is offered while running.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportDialog(vm: EditorViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var preset by remember { mutableStateOf(ExportConfig.Preset.P720_PORTRAIT) }
    var fps by remember { mutableStateOf(24) }
    var includeAudio by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    val exportState by ExportState.state.collectAsState()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri: Uri? ->
        if (uri != null) {
            vm.export(ExportConfig(preset.w, preset.h, fps, includeAudio), uri)
        } else onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export MP4") },
        text = {
            Column {
                when (val s = exportState) {
                    is ExportState.Status.Running -> {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                progress = { s.done.toFloat() / s.total.coerceAtLeast(1) },
                                modifier = Modifier.width(48.dp).height(48.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("Rendering ${s.done}/${s.total} frames…")
                        }
                    }
                    is ExportState.Status.Success -> Text("Export complete! Saved to your chosen location.")
                    is ExportState.Status.Failed -> Text("Export failed: ${s.message}")
                    ExportState.Status.Cancelled -> Text("Export cancelled.")
                    ExportState.Status.Idle -> {
                        ExposedDropdownMenuBox(menuOpen, { menuOpen = it }) {
                            OutlinedTextField(
                                value = preset.label, onValueChange = {},
                                readOnly = true, label = { Text("Resolution") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(menuOpen) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(menuOpen, { menuOpen = false }) {
                                ExportConfig.Preset.entries.forEach { p ->
                                    DropdownMenuItem({ Text(p.label) }, { preset = p; menuOpen = false })
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row {
                            listOf(12, 24, 30, 60).forEach { f ->
                                TextButton(onClick = { fps = f }) { Text("${f}fps") }
                            }
                        }
                        TextButton(onClick = { includeAudio = !includeAudio }) {
                            Text(if (includeAudio) "Audio: on" else "Audio: off")
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (exportState is ExportState.Status.Idle) {
                Button(onClick = { filePicker.launch("stickmotion_${System.currentTimeMillis()}.mp4") }) {
                    Text("Export")
                }
            } else if (exportState is ExportState.Status.Running) {
                Button(onClick = { ExportService.cancel(context); onDismiss() }) { Text("Cancel") }
            } else {
                Button(onClick = onDismiss) { Text("Close") }
            }
        },
        dismissButton = {
            if (exportState is ExportState.Status.Idle) TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
