package com.stickmotion.studio.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import com.stickmotion.studio.core.JointId
import com.stickmotion.studio.core.Project
import com.stickmotion.studio.core.Vec2
import com.stickmotion.studio.core.vec2
import com.stickmotion.studio.render.SceneRenderer
import com.stickmotion.studio.viewmodel.EditorViewModel

/**
 * Interactive animation stage. Touch is converted from screen pixels to stage
 * coordinates (inverting the renderer's letterbox + y-flip), the nearest
 * joint is hit-tested, and drags are forwarded to the view model's IK solver.
 */
@Composable
fun StageCanvas(
    vm: EditorViewModel,
    project: Project,
    frame: Float,
    modifier: Modifier = Modifier
) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    var lastStagePos by remember { mutableStateOf<Vec2?>(null) }

    val selectedCharId = vm.selectedCharId.value
    val selectedJoint = vm.selectedJoint.value
    val working = vm.workingPose.value

    // Render project, but override the dragged character's pose with the
    // uncommitted working pose so the drag is visible in real time.
    val renderProject = if (working != null) {
        val (cid, pose) = working
        project.updateCharacter(cid) { it.copy(
            track = it.track.withKeyframe(com.stickmotion.studio.core.Keyframe(frame.toInt(), pose))
        ) }
    } else project

    Canvas(modifier = modifier
        .fillMaxSize()
        .pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { offset ->
                    val stage = toStageCoords(offset, size, project) ?: return@detectDragGestures
                    val fk = com.stickmotion.studio.core.ForwardKinematics.solve(
                        project.characterById(selectedCharId ?: return@detectDragGestures)!!.poseAt(frame),
                        project.characterById(selectedCharId)!!.config
                    )
                    val hit = com.stickmotion.studio.core.InverseKinematics.hitTest(
                        fk.positions, stage, 40f / scaleOf(size, project)
                    )
                    if (hit != null) { vm.beginDrag(hit); lastStagePos = stage }
                },
                onDrag = { change, _ ->
                    val stage = toStageCoords(change.position, size, project) ?: return@detectDragGestures
                    val j = vm.selectedJoint.value ?: return@detectDragGestures
                    if (j == JointId.HIPS) {
                        // Dragging hips moves the whole figure (root translation).
                        // Implemented via torso/root: handled by commit using pose root.
                    } else {
                        vm.dragJoint(j, stage)
                    }
                    lastStagePos = stage
                },
                onDragEnd = { vm.commitDrag() },
                onDragCancel = { vm.cancelDrag() }
            )
        }
    ) {
        size = this.size.let { IntSize(it.width.toInt(), it.height.toInt()) }
        drawIntoCanvas { canvas ->
            SceneRenderer.draw(
                canvas.nativeCanvas, renderProject, frame,
                size.width, size.height,
                showHandles = true,
                selectedJoint = selectedJoint,
                selectedCharacterId = selectedCharId
            )
        }
    }
}

private fun scaleOf(size: IntSize, project: Project): Float =
    minOf(size.width / project.stageWidth.toFloat(), size.height / project.stageHeight.toFloat())

/** Convert a screen touch offset to project stage coordinates (y-up), or null if unknown. */
private fun toStageCoords(offset: Offset, size: IntSize, project: Project): Vec2? {
    if (size.width == 0) return null
    val scale = scaleOf(size, project)
    val offsetX = (size.width - project.stageWidth * scale) / 2f
    val offsetY = (size.height - project.stageHeight * scale) / 2f
    val sx = (offset.x - offsetX) / scale
    val sy = project.stageHeight - (offset.y - offsetY) / scale // flip y
    return vec2(sx, sy)
}
