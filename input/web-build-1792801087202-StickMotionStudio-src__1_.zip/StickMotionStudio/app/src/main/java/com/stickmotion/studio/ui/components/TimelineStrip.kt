package com.stickmotion.studio.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.stickmotion.studio.core.Project

/**
 * Compact timeline: one row per character track with keyframe diamonds, a
 * draggable playhead, and frame tick marks. Horizontal drag scrubs; a tap on
 * empty area seeks (the editor's keyframe buttons add/remove).
 */
@Composable
fun TimelineStrip(
    project: Project,
    frame: Float,
    onScrub: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val rowH = 28.dp
    val totalH = (project.characters.size * 28 + 24).dp
    Canvas(modifier = modifier
        .fillMaxWidth()
        .height(totalH)
        .pointerInput(project.durationFrames) {
            detectHorizontalDragGestures { change, _ ->
                val f = (change.position.x / size.width) * project.durationFrames
                onScrub(f.coerceIn(0f, project.durationFrames.toFloat()))
            }
        }
    ) {
        val w = size.width
        val trackH = 28.dp.toPx()
        // Ruler
        drawLine(Color(0xFF555555), Offset(0f, 20f), Offset(w, 20f), strokeWidth = 1f)
        for (f in 0..project.durationFrames step (project.fps * 2).coerceAtLeast(2)) {
            val x = f.toFloat() / project.durationFrames * w
            drawLine(Color(0xFF777777), Offset(x, 12f), Offset(x, 20f), strokeWidth = 1f)
        }
        project.characters.forEachIndexed { idx, ch ->
            val y0 = 24f + idx * trackH
            drawLine(Color(0xFF333333), Offset(0f, y0 + trackH / 2), Offset(w, y0 + trackH / 2), 1f)
            for (kf in ch.track.keyframes) {
                val x = kf.frame.toFloat() / project.durationFrames * w
                drawCircle(Color(0xFFFFB300), 5f, Offset(x, y0 + trackH / 2))
            }
        }
        // Playhead
        val px = frame / project.durationFrames * w
        drawLine(Color(0xFF81D4FA), Offset(px, 0f), Offset(px, size.height), strokeWidth = 2f)
    }
}
