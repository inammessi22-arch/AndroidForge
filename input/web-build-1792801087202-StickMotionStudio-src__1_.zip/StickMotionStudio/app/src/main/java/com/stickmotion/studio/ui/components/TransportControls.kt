package com.stickmotion.studio.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.stickmotion.studio.viewmodel.EditorViewModel

/** Playback + edit transport row. All buttons have content descriptions (a11y). */
@Composable
fun TransportControls(vm: EditorViewModel, frame: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { vm.undo() }, enabled = vm.canUndo.value) {
            Icon(Icons.Default.Undo, contentDescription = "Undo")
        }
        IconButton(onClick = { vm.redo() }, enabled = vm.canRedo.value) {
            Icon(Icons.Default.Redo, contentDescription = "Redo")
        }
        IconButton(onClick = { vm.step(-1) }) {
            Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Previous frame")
        }
        IconButton(onClick = { vm.togglePlay() }) {
            Icon(
                if (vm.playing.value) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (vm.playing.value) "Pause" else "Play"
            )
        }
        IconButton(onClick = { vm.step(1) }) {
            Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Next frame")
        }
        IconButton(onClick = { vm.copyPose() }) {
            Icon(Icons.Default.ContentCopy, contentDescription = "Copy pose")
        }
        IconButton(onClick = { vm.pastePose() }) {
            Icon(Icons.Default.ContentPaste, contentDescription = "Paste pose")
        }
        Text("f.$frame", modifier = Modifier.padding(start = 4.dp))
    }
}
