package com.stickmotion.studio.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stickmotion.studio.core.Presets
import com.stickmotion.studio.ui.components.ExportDialog
import com.stickmotion.studio.ui.components.StageCanvas
import com.stickmotion.studio.ui.components.TimelineStrip
import com.stickmotion.studio.ui.components.TransportControls
import com.stickmotion.studio.viewmodel.EditorViewModel
import kotlinx.coroutines.android.withFrameNanos

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    projectId: String,
    onBack: () -> Unit,
    vm: EditorViewModel = viewModel()
) {
    val project by vm.project.collectAsState()
    val frame by vm.frame.collectAsState()
    val playing by vm.playing.collectAsState()
    var showExport by remember { mutableStateOf(false) }

    LaunchedEffect(projectId) { vm.load(projectId) }

    // Playback loop: advance frame in sync with the display vsync.
    LaunchedEffect(playing) {
        var last = 0L
        while (playing) {
            withFrameNanos { now ->
                if (last != 0L) vm.advanceBy((now - last) / 1_000_000L)
                last = now
            }
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.setBackgroundImage(it) }
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.addAudio(it, "Audio track") }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(project?.name ?: "Editor") },
                navigationIcon = {
                    IconButton(onClick = { onBack() }) { Icon(Icons.Default.ArrowBack, "Back") }
                },
                actions = {
                    IconButton(onClick = { vm.addCharacter() }) { Icon(Icons.Default.PersonAdd, "Add character") }
                    IconButton(onClick = { showExport = true }) { Icon(Icons.Default.Videocam, "Export MP4") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            val p = project
            if (p == null) {
                Text("Loading…", Modifier.padding(16.dp))
                return@Column
            }

            // Character selector chips
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                p.characters.forEach { ch ->
                    FilterChip(
                        selected = ch.id == vm.selectedCharId.value,
                        onClick = { vm.selectCharacter(ch.id) },
                        label = { Text(ch.name) }
                    )
                }
            }

            // Animation stage (weighted to fill space)
            StageCanvas(vm, p, frame, Modifier.weight(1f))

            // Preset row (scrollable)
            Row(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Presets.Id.entries.forEach { id ->
                    FilterChip(selected = false, onClick = { vm.applyPreset(id) }, label = { Text(id.label) })
                }
                FilterChip(selected = false, onClick = { imagePicker.launch(arrayOf("image/*")) }, label = { Text("BG image") })
                FilterChip(selected = false, onClick = { audioPicker.launch(arrayOf("audio/*")) }, label = { Text("Add audio") })
                FilterChip(selected = false, onClick = { vm.setKeyframeHere() }, label = { Text("+Key") })
                FilterChip(selected = false, onClick = { vm.deleteKeyframeHere() }, label = { Text("-Key") })
            }

            TimelineStrip(p, frame, onScrub = { vm.scrub(it) })
            Spacer(Modifier.height(4.dp))
            TransportControls(vm, frame.toInt())
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showExport) ExportDialog(vm, onDismiss = { showExport = false })
}
