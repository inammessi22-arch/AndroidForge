package com.stickmotion.studio.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.stickmotion.studio.data.ProjectRepository
import com.stickmotion.studio.viewmodel.GalleryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenProject: (String) -> Unit,
    onShowLicenses: () -> Unit,
    vm: GalleryViewModel = viewModel()
) {
    val summaries by vm.summaries.collectAsState()
    val error by vm.error.collectAsState()
    LaunchedEffect(Unit) { vm.refresh() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.import(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("StickMotion Studio") }, actions = {
                IconButton(onClick = { importLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*")) }) {
                    Icon(Icons.Default.FileOpen, contentDescription = "Import project")
                }
                IconButton(onClick = onShowLicenses) {
                    Icon(Icons.Default.Edit, contentDescription = "Open source licenses") // placeholder icon
                }
            })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onOpenProject(vm.createNew()) },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("New project") }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            error?.let {
                Text("Import error: $it", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
            }
            if (summaries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No projects yet. Tap “New project” to start animating!")
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(12.dp)) {
                items(summaries, key = { it.id }) { s ->
                    ProjectCard(s,
                        onOpen = { onOpenProject(s.id) },
                        onRename = { vm.rename(s.id, promptRename(s.name)) },
                        onDuplicate = { vm.duplicate(s.id) },
                        onDelete = { vm.delete(s.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProjectCard(
    s: ProjectRepository.Summary,
    onOpen: () -> Unit, onRename: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.name, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(s.modifiedMs)),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            IconButton(onClick = onRename) { Icon(Icons.Default.Edit, "Rename") }
            IconButton(onClick = onDuplicate) { Icon(Icons.Default.ContentCopy, "Duplicate") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
        }
    }
}

/** Rename uses a simple inline prompt pattern; in production use an AlertDialog TextField. */
private fun promptRename(current: String): String = "$current (renamed)"
