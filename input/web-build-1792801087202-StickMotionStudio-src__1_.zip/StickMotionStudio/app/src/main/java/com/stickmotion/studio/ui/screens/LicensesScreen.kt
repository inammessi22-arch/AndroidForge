package com.stickmotion.studio.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * In-app open-source notices. This list MUST stay in sync with
 * THIRD_PARTY_NOTICES.md in the repository. Full license texts are shipped
 * in assets/third_party_licenses.txt and shown on request.
 */
private data class Notice(val name: String, val license: String, val purpose: String)

private val NOTICES = listOf(
    Notice("Kotlin stdlib + kotlinx-serialization", "Apache-2.0", "Language runtime & project JSON format"),
    Notice("AndroidX (Core, Activity, Lifecycle, Compose, Material3)", "Apache-2.0", "UI framework & Jetpack"),
    Notice("Android framework (MediaCodec, MediaMuxer, MediaExtractor)", "Apache-2.0", "MP4 video encoding & audio muxing"),
    Notice("JUnit 4 (dev-only, not bundled)", "EPL-1.0", "Unit tests"),
    Notice("Gradle (build tool, not bundled)", "Apache-2.0", "Build system")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LicensesScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Open Source Licenses") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Text(
                "StickMotion Studio is open source (Apache-2.0). It uses the following third-party components. " +
                    "Full license texts are available in the source repository under THIRD_PARTY_NOTICES.md.",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            NOTICES.forEach { n ->
                Text(n.name, style = MaterialTheme.typography.titleSmall)
                Text("License: ${n.license} · ${n.purpose}", style = MaterialTheme.typography.bodySmall)
                androidx.compose.foundation.layout.Spacer(Modifier.padding(vertical = 6.dp))
            }
            Text(
                "No code from StykAnimate (GPL-3.0), mooltik (GPL-3.0), or hmelberg/stick (unlicensed) is included. " +
                    "If GPL-licensed features are added later, the combined work must be relicensed GPL-3.0.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}
