package com.stickmotion.studio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

private val SLIDES = listOf(
    "Welcome to StickMotion Studio!\n\nDrag any joint (head, elbows, wrists, knees, ankles) to pose your stickman.",
    "Tap +Key to save a pose at the current frame, then move the playhead and pose again. StickMotion fills in the motion between keyframes.",
    "Apply motion presets (walk, run, jump…), add backgrounds & audio, then export a real MP4. Everything works offline — no account, no subscription."
)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("${step + 1} / ${SLIDES.size}", style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(16.dp))
        Text(
            SLIDES[step],
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(32.dp))
        Button(onClick = {
            if (step < SLIDES.size - 1) step++ else onDone()
        }) {
            Text(if (step < SLIDES.size - 1) "Next" else "Start animating")
        }
    }
}
