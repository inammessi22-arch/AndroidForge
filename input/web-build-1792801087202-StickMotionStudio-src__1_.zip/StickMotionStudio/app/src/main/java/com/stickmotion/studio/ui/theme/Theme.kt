package com.stickmotion.studio.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Dark-first theme (editor is dark by default to reduce eye strain).
private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB300),
    onPrimary = Color(0xFF1A1C1E),
    secondary = Color(0xFF81D4FA),
    background = Color(0xFF121417),
    surface = Color(0xFF1E2126),
    onSurface = Color(0xFFE8EAED),
    surfaceVariant = Color(0xFF2A2E35),
    error = Color(0xFFFF8A80)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFFE65100),
    secondary = Color(0xFF0277BD),
    background = Color(0xFFFAFAFA),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1C1E)
)

@Composable
fun StickMotionTheme(dark: Boolean = true, content: @Composable () -> Unit) {
    // Force dark for the editor stage; users expect animation tools to be dark.
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
