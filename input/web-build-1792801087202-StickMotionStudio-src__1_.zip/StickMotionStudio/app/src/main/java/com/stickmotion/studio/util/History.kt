package com.stickmotion.studio.util

/**
 * Bounded undo/redo stack. Snapshots are immutable [Project] copies (cheap
 * because lists/maps are persistent-ish on copy). Pure Kotlin.
 */
class History<T>(private val maxSize: Int = 50) {
    private val undoStack = ArrayDeque<T>()
    private val redoStack = ArrayDeque<T>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun push(snapshot: T) {
        undoStack.addLast(snapshot)
        if (undoStack.size > maxSize) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo(current: T): T? {
        if (undoStack.isEmpty()) return null
        val prev = undoStack.removeLast()
        redoStack.addLast(current)
        return prev
    }

    fun redo(current: T): T? {
        if (redoStack.isEmpty()) return null
        val next = redoStack.removeLast()
        undoStack.addLast(current)
        return next
    }

    fun clear() { undoStack.clear(); redoStack.clear() }
}
