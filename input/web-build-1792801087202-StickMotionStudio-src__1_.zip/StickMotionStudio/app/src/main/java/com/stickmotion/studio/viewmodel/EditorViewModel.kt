package com.stickmotion.studio.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.stickmotion.studio.StickMotionApp
import com.stickmotion.studio.core.Background
import com.stickmotion.studio.core.Character
import com.stickmotion.studio.core.Easing
import com.stickmotion.studio.core.ExportConfig
import com.stickmotion.studio.core.InverseKinematics
import com.stickmotion.studio.core.JointId
import com.stickmotion.studio.core.Keyframe
import com.stickmotion.studio.core.Pose
import com.stickmotion.studio.core.Presets
import com.stickmotion.studio.core.Project
import com.stickmotion.studio.core.StickmanConfig
import com.stickmotion.studio.core.Vec2
import com.stickmotion.studio.core.vec2
import com.stickmotion.studio.render.ExportService
import com.stickmotion.studio.util.History
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * All editing state lives here. The [project] flow is the single source of
 * truth; every mutation pushes the previous snapshot onto the undo stack.
 * A working pose (drag in progress, not yet keyframed) is kept separately so
 * scrubbing and playing are never blocked by an uncommitted drag.
 */
class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = (app as StickMotionApp).repository

    private val _project = MutableStateFlow<Project?>(null)
    val project: StateFlow<Project?> = _project.asStateFlow()

    private val _frame = MutableStateFlow(0f)
    val frame: StateFlow<Float> = _frame.asStateFlow()

    private val _playing = MutableStateFlow(false)
    val playing: StateFlow<Boolean> = _playing.asStateFlow()

    private val _selectedCharId = MutableStateFlow<String?>(null)
    val selectedCharId: StateFlow<String?> = _selectedCharId.asStateFlow()

    private val _selectedJoint = MutableStateFlow<JointId?>(null)
    val selectedJoint: StateFlow<JointId?> = _selectedJoint.asStateFlow()

    /** Pose currently being dragged (null when no drag active). */
    private val _workingPose = MutableStateFlow<Pair<String, Pose>?>(null)
    val workingPose: StateFlow<Pair<String, Pose>?> = _workingPose.asStateFlow()

    private val history = History<Project>()
    val canUndo: StateFlow<Boolean> = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = MutableStateFlow(false)

    private var clipboard: Pose? = null
    private var autosaveJob: Job? = null

    fun load(projectId: String) {
        viewModelScope.launch {
            val p = repo.load(projectId) ?: Project.newEmpty("Untitled")
            _project.value = p
            _selectedCharId.value = p.characters.firstOrNull()?.id
            history.clear()
            scheduleAutosave()
        }
    }

    private fun mutate(transform: (Project) -> Project) {
        val cur = _project.value ?: return
        history.push(cur)
        (canUndo as MutableStateFlow).value = true
        (canRedo as MutableStateFlow).value = false
        _project.value = transform(cur)
        scheduleAutosave()
    }

    private fun scheduleAutosave() {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(800)
            _project.value?.let { repo.save(it) }
        }
    }

    suspend fun saveNow() { _project.value?.let { repo.save(it) } }

    // ---- playback ----
    fun togglePlay() { _playing.value = !_playing.value }
    fun scrub(frame: Float) {
        val p = _project.value ?: return
        _frame.value = frame.coerceIn(0f, p.durationFrames.toFloat())
    }
    fun step(delta: Int) {
        val p = _project.value ?: return
        _frame.value = (_frame.value + delta).coerceIn(0f, p.durationFrames.toFloat())
    }
    fun advanceBy(dtMs: Long) {
        val p = _project.value ?: return
        val df = dtMs * p.fps / 1000f
        var next = _frame.value + df
        if (next >= p.durationFrames) next = if (p.loop) next - p.durationFrames else p.durationFrames.toFloat().also { _playing.value = false }
        _frame.value = next
    }
    fun setFps(fps: Int) { mutate { it.copy(fps = fps.coerceIn(1, 60)) } }
    fun setDuration(frames: Int) { mutate { it.copy(durationFrames = frames.coerceAtLeast(1)) } }

    // ---- selection ----
    fun selectCharacter(id: String) { _selectedCharId.value = id }
    fun selectJoint(j: JointId?) { _selectedJoint.value = j }

    // ---- joint dragging with IK ----
    fun beginDrag(joint: JointId) {
        val p = _project.value ?: return
        val cid = _selectedCharId.value ?: return
        _workingPose.value = cid to p.characterById(cid)!!.poseAt(_frame.value)
        _selectedJoint.value = joint
    }

    /**
     * Drag [joint] to stage-coordinate [target]. Solves the two-bone IK chain
     * for wrists/ankles; for other joints, rotates the parent bone toward the
     * target. Updates the working pose only; call [commitDrag] to keyframe it.
     */
    fun dragJoint(joint: JointId, target: Vec2) {
        val (cid, pose) = _workingPose.value ?: return
        val p = _project.value ?: return
        val ch = p.characterById(cid) ?: return
        val cfg = ch.config
        val fk = com.stickmotion.studio.core.ForwardKinematics.solve(pose, cfg)
        val positions = fk.positions
        var newPose = pose

        when (joint) {
            JointId.L_WRIST, JointId.R_WRIST -> {
                val shoulder = if (joint == JointId.L_WRIST) JointId.L_SHOULDER else JointId.R_SHOULDER
                val elbow = if (joint == JointId.L_WRIST) JointId.L_ELBOW else JointId.R_ELBOW
                val parentAngle = 0f // shoulder world angle reference; computed from chest below
                val chestWorld = pose.angleOf(JointId.CHEST)
                val sol = InverseKinematics.solve2Bone(
                    positions[shoulder]!!, chestWorld, target,
                    cfg.upperArm, cfg.foreArm, +1f
                )
                newPose = newPose.withAngle(shoulder, sol.angle1).withAngle(elbow, sol.angle2)
            }
            JointId.L_ANKLE, JointId.R_ANKLE -> {
                val hip = if (joint == JointId.L_ANKLE) JointId.L_HIP else JointId.R_HIP
                val knee = if (joint == JointId.L_ANKLE) JointId.L_KNEE else JointId.R_KNEE
                val sol = InverseKinematics.solve2Bone(
                    positions[hip]!!, 0f, target,
                    cfg.upperLeg, cfg.lowerLeg, -1f // knees bend backward
                )
                newPose = newPose.withAngle(hip, sol.angle1).withAngle(knee, sol.angle2)
            }
            JointId.HEAD, JointId.NECK, JointId.CHEST -> {
                // Rotate torso toward target by adjusting chest angle.
                val hips = positions[JointId.HIPS]!!
                val desired = kotlin.math.atan2((target - hips).x.toDouble(), (target - hips).y.toDouble()).toFloat()
                newPose = newPose.withAngle(JointId.CHEST, -desired)
            }
            else -> {
                // Elbow/knee/shoulder/hip single-bone rotate toward target.
                val parent = joint.parent ?: return
                val rootPos = positions[parent]!!
                val desired = -kotlin.math.atan2((target - rootPos).x.toDouble(), (target - rootPos).y.toDouble()).toFloat()
                val parentWorld = when (parent) {
                    JointId.CHEST -> pose.angleOf(JointId.CHEST)
                    JointId.L_SHOULDER -> pose.angleOf(JointId.CHEST) + pose.angleOf(JointId.L_SHOULDER)
                    JointId.R_SHOULDER -> pose.angleOf(JointId.CHEST) + pose.angleOf(JointId.R_SHOULDER)
                    JointId.L_HIP -> pose.angleOf(JointId.L_HIP)
                    JointId.R_HIP -> pose.angleOf(JointId.R_HIP)
                    else -> 0f
                }
                newPose = newPose.withAngle(joint, com.stickmotion.studio.core.normalizeAngle(desired - parentWorld))
            }
        }
        _workingPose.value = cid to newPose
    }

    /** Commit the working pose as a keyframe at the current frame. */
    fun commitDrag() {
        val (cid, pose) = _workingPose.value ?: return
        val f = _frame.value.toInt()
        mutate { it.withKeyframe(cid, Keyframe(f, pose, Easing.EASE_IN_OUT)) }
        _workingPose.value = null
    }

    fun cancelDrag() { _workingPose.value = null; _selectedJoint.value = null }

    fun setKeyframeHere() {
        val cid = _selectedCharId.value ?: return
        val p = _project.value ?: return
        val pose = p.characterById(cid)!!.poseAt(_frame.value)
        mutate { it.withKeyframe(cid, Keyframe(_frame.value.toInt(), pose, Easing.EASE_IN_OUT)) }
    }

    fun deleteKeyframeHere() {
        val cid = _selectedCharId.value ?: return
        mutate { it.removeKeyframe(cid, _frame.value.toInt()) }
    }

    // ---- copy / paste pose ----
    fun copyPose() {
        val cid = _selectedCharId.value ?: return
        clipboard = _project.value?.characterById(cid)?.poseAt(_frame.value)
    }
    fun pastePose() {
        val cid = _selectedCharId.value ?: return
        val pose = clipboard ?: return
        mutate { it.withKeyframe(cid, Keyframe(_frame.value.toInt(), pose, Easing.EASE_IN_OUT)) }
    }

    // ---- undo / redo ----
    fun undo() {
        val cur = _project.value ?: return
        history.undo(cur)?.let { prev ->
            _project.value = prev
            (canRedo as MutableStateFlow).value = true
            (canUndo as MutableStateFlow).value = history.canUndo
            scheduleAutosave()
        }
    }
    fun redo() {
        val cur = _project.value ?: return
        history.redo(cur)?.let { next ->
            _project.value = next
            (canUndo as MutableStateFlow).value = true
            (canRedo as MutableStateFlow).value = history.canRedo
            scheduleAutosave()
        }
    }

    // ---- presets ----
    fun applyPreset(id: Presets.Id, cycleFrames: Int = 48) {
        val cid = _selectedCharId.value ?: return
        val p = _project.value ?: return
        val base = p.characterById(cid)!!.poseAt(_frame.value)
        val startFrame = _frame.value.toInt()
        val kfs = Presets.generate(id, base, cycleFrames).map { it.copy(frame = it.frame + startFrame) }
        mutate { proj ->
            proj.updateCharacter(cid) { ch ->
                var t = ch.track
                for (kf in kfs) t = t.withKeyframe(kf)
                ch.withTrack(t)
            }.copy(durationFrames = maxOf(proj.durationFrames, startFrame + cycleFrames))
        }
    }

    // ---- characters / background / audio ----
    fun addCharacter() {
        mutate { it.addCharacter(Character(
            id = Character.newId(), name = "Stickman ${it.characters.size + 1}",
            config = StickmanConfig(colorArgb = randomPastel()),
            track = com.stickmotion.studio.core.Track(listOf(Keyframe(0, Pose.neutral(root = vec2(
                it.stageWidth / 2f + (it.characters.size * 60f - 60f), it.stageHeight * 0.35f)))))
        )) }
    }
    fun removeSelectedCharacter() {
        val cid = _selectedCharId.value ?: return
        mutate { it.removeCharacter(cid) }
        _selectedCharId.value = _project.value?.characters?.firstOrNull()?.id
    }
    fun setBackgroundColor(argb: Int) { mutate { it.copy(background = it.background.copy(colorArgb = argb)) } }
    fun setBackgroundImage(uri: Uri?) { mutate { it.copy(background = it.background.copy(imageUri = uri?.toString())) } }
    fun addAudio(uri: Uri, name: String) {
        mutate { it.copy(audioTracks = it.audioTracks + AudioTrack(
            id = "audio_${System.nanoTime()}", sourceUri = uri.toString(), name = name)) }
    }

    fun export(config: ExportConfig, outputUri: Uri) {
        val p = _project.value ?: return
        ExportService.start(getApplication(), p, config, outputUri)
    }

    private fun randomPastel(): Int {
        val hues = listOf(0xFFB0BEC5.toInt(), 0xFFC8E6C9.toInt(), 0xFFFFCCBC.toInt(), 0xFFFFF9C4.toInt(), 0xFFD1C4E9.toInt())
        return hues.random()
    }
}
