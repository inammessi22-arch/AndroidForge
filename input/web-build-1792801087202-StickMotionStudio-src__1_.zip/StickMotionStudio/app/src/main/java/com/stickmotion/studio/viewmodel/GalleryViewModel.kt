package com.stickmotion.studio.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.stickmotion.studio.StickMotionApp
import com.stickmotion.studio.core.Project
import com.stickmotion.studio.data.ProjectRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as StickMotionApp).repository

    private val _summaries = MutableStateFlow<List<ProjectRepository.Summary>>(emptyList())
    val summaries: StateFlow<List<ProjectRepository.Summary>> = _summaries.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun refresh() {
        viewModelScope.launch { _summaries.value = repo.listSummaries() }
    }

    fun createNew(name: String = "Untitled"): String {
        val p = Project.newEmpty(name)
        viewModelScope.launch { repo.save(p); refresh() }
        return p.id
    }

    fun delete(id: String) { viewModelScope.launch { repo.delete(id); refresh() } }
    fun duplicate(id: String) { viewModelScope.launch { repo.duplicate(id); refresh() } }
    fun rename(id: String, name: String) { viewModelScope.launch { repo.rename(id, name); refresh() } }

    fun import(uri: Uri) {
        viewModelScope.launch {
            repo.importFromUri(uri).onFailure { _error.value = it.message ?: "Import failed" }
                .onSuccess { _error.value = null }
            refresh()
        }
    }

    fun clearError() { _error.value = null }
}
