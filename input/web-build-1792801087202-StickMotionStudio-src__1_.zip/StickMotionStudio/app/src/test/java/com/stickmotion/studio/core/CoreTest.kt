package com.stickmotion.studio.core

import com.stickmotion.studio.data.ProjectSerializer
import com.stickmotion.studio.util.History
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * JVM unit tests (run with `./gradlew test`). These mirror the standalone
 * harness in standalone-test/TestRunner.kt, which was executed in the build
 * environment (76/76 passing) because no Android SDK was available there.
 */
class CoreTest {

    private fun approx(a: Float, b: Float, eps: Float = 0.01f) = abs(a - b) <= eps

    @Test fun vec2Length() = assertEquals(5f, vec2(3f, 4f).length(), 0.001f)

    @Test fun shortestAngleLerp() =
        assertTrue(approx(toDeg(lerpAngle(deg(350f), deg(10f), 0.5f)), 0f, 0.5f))

    @Test fun easingEndpoints() {
        for (e in Easing.entries) if (e != Easing.HOLD) {
            assertTrue(approx(e.apply(0f), 0f)); assertTrue(approx(e.apply(1f), 1f))
        }
    }

    @Test fun forwardKinematicsNeutral() {
        val fk = ForwardKinematics.solve(Pose.neutral(vec2(0f, 100f)), StickmanConfig())
        assertTrue(fk.headCenter.y > 100f)
        assertTrue(fk.positions[JointId.L_ANKLE]!!.y < 100f)
        assertEquals(12, fk.bones.size)
    }

    @Test fun inverseKinematicsReachesTarget() {
        val root = vec2(0f, 0f)
        val target = vec2(50f, 80f)
        val sol = InverseKinematics.solve2Bone(root, 0f, target, 70f, 60f, +1f)
        assertTrue(sol.reached)
        val w1 = sol.angle1; val w2 = w1 + sol.angle2
        val end = root + Vec2.UP.rotate(w1) * 70f + Vec2.UP.rotate(w2) * 60f
        assertTrue(end.distanceTo(target) < 1f)
    }

    @Test fun trackInterpolationAndHold() {
        val t = Track(listOf(
            Keyframe(0, Pose.neutral(vec2(0f, 0f)), Easing.LINEAR),
            Keyframe(10, Pose.neutral(vec2(100f, 0f)), Easing.LINEAR)))
        assertEquals(0f, t.poseAt(-5f).root.x, 0.001f)
        assertEquals(100f, t.poseAt(20f).root.x, 0.001f)
        assertEquals(50f, t.poseAt(5f).root.x, 0.001f)
    }

    @Test fun unsortedKeyframesRejected() {
        var threw = false
        try { Track(listOf(Keyframe(5, Pose.neutral()), Keyframe(1, Pose.neutral()))) }
        catch (_: IllegalArgumentException) { threw = true }
        assertTrue(threw)
    }

    @Test fun presetsAreSortedAndFinite() {
        val base = Pose.neutral(vec2(360f, 400f))
        for (id in Presets.Id.entries) {
            val kfs = Presets.generate(id, base, 48)
            assertTrue(kfs.isNotEmpty())
            assertEquals(kfs.map { it.frame }, kfs.map { it.frame }.sorted())
            assertEquals(48, kfs.last().frame)
        }
    }

    @Test fun serializationRoundTrip() {
        val proj = Project.newEmpty("RT").let {
            it.withKeyframe(it.characters.first().id, Keyframe(24, Pose.neutral(vec2(500f, 300f))))
        }
        val decoded = ProjectSerializer.decodeValidated(ProjectSerializer.encode(proj))
        assertTrue(decoded.isSuccess)
        val d = decoded.getOrThrow()
        assertEquals(proj.name, d.name)
        assertEquals(2, d.characters.first().track.keyframes.size)
        assertTrue(approx(d.characters.first().track.keyframes[1].pose.root.x, 500f, 0.5f))
    }

    @Test fun validationRejectsBadInput() {
        val json = ProjectSerializer.encode(Project.newEmpty("X"))
        assertTrue(ProjectSerializer.decodeValidated(json.replaceFirst("\"fps\": 24", "\"fps\": 999")).isFailure)
        assertTrue(ProjectSerializer.decodeValidated("not json").isFailure)
    }

    @Test fun undoRedo() {
        val h = History<Int>(); h.push(1); h.push(2)
        assertTrue(h.canUndo)
        assertEquals(2, h.undo(3))
        assertEquals(3, h.redo(2))
        assertFalse(h.canRedo.let { h.undo(3); h.push(9); h.canRedo })
    }
}
