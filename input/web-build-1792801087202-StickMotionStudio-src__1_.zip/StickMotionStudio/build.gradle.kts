// Top-level build file. Plugin versions are pinned here so the build is
// reproducible. Bump together with the Gradle wrapper (see gradle/wrapper).
plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "1.9.24" apply false
}
