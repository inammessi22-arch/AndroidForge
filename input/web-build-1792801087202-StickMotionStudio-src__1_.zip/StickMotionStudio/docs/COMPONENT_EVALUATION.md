# Component Evaluation — StickMotion Studio

Phase 1 open-source research. Inspected 2026-10-23 via GitHub API + raw
LICENSE/README/manifest files. **No code from any of these repositories is
copied into StickMotion Studio.** They were evaluated only as candidates.

| Feature / Repo | License | Platform / Language | Android-compatible? | Maintenance | Integration effort | Attribution / redistribution obligations | Verdict |
|---|---|---|---|---|---|---|---|
| [filippocalippo/StykAnimate-App](https://github.com/filippocalippo/StykAnimate-App) | **GPL-3.0** (verified in LICENSE file) | Electron + WebGPU, JavaScript; Windows/Linux/browser only | **No** — not an Android app; would need full port to Kotlin/Compose | Very active (pushed same day, 733★) | Very high — different language, renderer, and build system | Copyleft: any distributed derivative (including an Android port) must be released under GPL-3.0 with full source | Not reused. Pivot/Stick Nodes file-format ideas referenced only as inspiration. If its importers are ever ported, the combined app must be relicensed GPL-3.0. |
| [ruskakimov/mooltik](https://github.com/ruskakimov/mooltik) | **GPL-3.0** (GitHub API license field) | Flutter/Dart, Android+iOS; frame-by-frame *drawing* animation (not joint-based) | Runs on Android but via Flutter, incompatible with our Kotlin/Compose architecture | Active (last push Feb 2026, 224★) | High — would force Flutter + GPL; uses flutter_ffmpeg (LGPL/GPL, patent-encumbered) for export | GPL-3.0 copyleft + flutter_ffmpeg LGPL/GPL obligations | Not reused. Different paradigm (drawing vs. skeleton joints). |
| [hmelberg/stick](https://github.com/hmelberg/stick) | **NO LICENSE** (license: null; no LICENSE file) | Tiny JavaScript JSON→SVG animation language, web demo only | No | Barely maintained (0★, 2 commits, last push Aug 2026) | N/A | **Unlicensed = all rights reserved.** Reuse without explicit written permission is copyright infringement. | **Unavailable for reuse.** Excluded entirely. |
| Android framework `MediaCodec` / `MediaMuxer` / `MediaExtractor` | Apache-2.0 | Built into Android | Yes | N/A (platform) | None — direct API calls | NOTICE file attribution (bundled in AOSP notices) | **Used** for genuine MP4 export + audio passthrough mux. |
| Kotlin stdlib + `kotlinx-serialization-json` | Apache-2.0 | JVM/Android | Yes | Active | Low (Gradle dep) | NOTICE attribution | **Used** — project file format. |
| AndroidX / Jetpack Compose / Material3 | Apache-2.0 | Android | Yes | Active | Low (Gradle deps) | NOTICE attribution | **Used** — UI. |
| JUnit 4 | EPL-1.0 | JVM (dev only) | N/A | Stable | Low | EPL notice; **not bundled in APK** | **Used** for unit tests only. |

## Additional repos considered
- `rula/StickNodes`-style apps: proprietary (Stick Nodes by ForTheLoss Games), not open source — excluded.
- Pivot Animator: Windows freeware, closed source — excluded.
- No maintained Android Kotlin joint-animation editor library was found with a permissive license. The custom Canvas + IK engine was therefore written from scratch.

## License decision
All bundled dependencies are permissive (Apache-2.0 / EPL dev-only). Original
code is therefore released under **Apache-2.0**. **Important:** if you later
copy or port code from StykAnimate or mooltik (both GPL-3.0), the combined
distributed work becomes a derivative of GPL code and **must be relicensed
GPL-3.0** with corresponding source offered. Do not mix GPL-3.0 code into this
Apache-2.0 codebase without changing the project license first.
