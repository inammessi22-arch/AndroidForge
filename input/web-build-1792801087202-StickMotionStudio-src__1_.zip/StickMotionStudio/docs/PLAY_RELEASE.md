# Google Play Release Checklist

**Current status (2026-10-23):** No APK/AAB has been built, signed, uploaded,
or accepted. The items below are the exact remaining steps.

## 1. Build & sign
- Install JDK 17 + Android SDK platform 35 + build-tools.
- `./gradlew wrapper --gradle-version 8.9` (wrapper jar not committed).
- Create a release keystore **outside the repo**:
  `keytool -genkeypair -alias stickmotion -keyalg RSA -keysize 2048 -validity 10000 -keystore stickmotion-release.jks`
- In `~/.gradle/gradle.properties` (never committed):
  `STICKMOTION_STORE_FILE=...`, `STICKMOTION_STORE_PASSWORD=...`,
  `STICKMOTION_KEY_ALIAS=stickmotion`, `STICKMOTION_KEY_PASSWORD=...`
- Wire these into `app/build.gradle.kts` `signingConfigs.release`.
- `./gradlew :app:bundleRelease` → `app/build/outputs/bundle/release/app-release.aab`

## 2. Play Console (as of publication time — verify current policy)
- targetSdk must meet Google's current target-API requirement (35 required
  from Aug 2025; a higher level may be required by your release date — bump
  compileSdk/targetSdk/AGP together).
- App content declarations: no ads, no data collection (Data safety form: all
  "No"). Content rating: E / Everyone.
- Upload AAB to internal testing track → run on real devices (Firebase Test
  Lab or manual) → promote to closed → open → production.
- Store listing: original app icon (res/drawable/ic_launcher_foreground.xml),
  feature graphic, screenshots (16:9 & 7-inch), short/full description.
- Privacy policy URL (host PRIVACY.md on GitHub Pages or your site).
- Target API level, Play App Signing enrollment, and (if exporting videos)
  declare no media permission misuse.

## 3. Pre-launch report fixes
Address crashes, accessibility, and security findings from the pre-launch
report before production. The in-app Licenses screen must be reachable from
settings (it is, via the home top bar).
