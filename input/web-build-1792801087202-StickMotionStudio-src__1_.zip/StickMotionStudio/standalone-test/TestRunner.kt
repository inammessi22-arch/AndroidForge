import com.stickmotion.studio.core.*
import com.stickmotion.studio.data.ProjectSerializer
import com.stickmotion.studio.util.History
import kotlin.math.abs
import kotlin.math.sin

/**
 * Standalone JVM test runner for the pure core. No Android, no JUnit —
 * plain asserts so it runs with a bare kotlinc. Mirrors the JUnit tests in
 * app/src/test so the same logic is verified in this environment.
 */
var passed = 0
var failed = 0

fun check(name: String, cond: Boolean) {
    if (cond) { passed++; println("  PASS  $name") }
    else { failed++; println("  FAIL  $name") }
}

fun approx(a: Float, b: Float, eps: Float = 0.01f) = abs(a - b) <= eps

fun main() {
    println("== Vec2 math ==")
    val a = vec2(3f, 4f)
    check("length", approx(a.length(), 5f))
    check("plus", (a + vec2(1f, 1f)) == vec2(4f, 5f))
    check("rotate 90", approx(vec2(1f, 0f).rotate(deg(90f)).y, 1f))
    check("lerp", approx(lerp(0f, 10f, 0.5f), 5f))

    println("== Angle math ==")
    check("normalize 360->0", approx(normalizeAngle(deg(360f)), 0f, 0.001f))
    check("shortest lerp 350->10", approx(toDeg(lerpAngle(deg(350f), deg(10f), 0.5f)), 0f, 0.5f))
    check("lerpAngle endpoints", approx(lerpAngle(0.2f, 0.8f, 0f), 0.2f) && approx(lerpAngle(0.2f, 0.8f, 1f), 0.8f))

    println("== Forward kinematics (neutral pose) ==")
    val cfg = StickmanConfig()
    val pose = Pose.neutral(root = vec2(360f, 400f))
    val fk = ForwardKinematics.solve(pose, cfg)
    check("head above hips", fk.headCenter.y > pose.root.y)
    check("ankles below hips", fk.positions[JointId.L_ANKLE]!!.y < pose.root.y)
    check("wrists below shoulders", fk.positions[JointId.L_WRIST]!!.y < fk.positions[JointId.L_SHOULDER]!!.y)
    check("bones count", fk.bones.size == 12) // 2 torso + 4 arm + 4 leg + 2 cross bars

    println("== Inverse kinematics (2-bone) ==")
    val root = vec2(0f, 0f)
    val target = vec2(50f, 80f)
    val sol = InverseKinematics.solve2Bone(root, 0f, target, 70f, 60f, +1f)
    check("reachable target", sol.reached)
    val world1 = 0f + sol.angle1
    val world2 = world1 + sol.angle2
    val end = root + Vec2.UP.rotate(world1) * 70f + Vec2.UP.rotate(world2) * 60f
    check("IK end effector matches target", end.distanceTo(target) < 1f)
    val far = InverseKinematics.solve2Bone(root, 0f, vec2(500f, 500f), 70f, 60f, +1f)
    check("unreachable clamped", !far.reached)
    check("hit test finds nearest", InverseKinematics.hitTest(
        mapOf(JointId.HEAD to vec2(100f, 100f), JointId.HIPS to vec2(0f, 0f)),
        vec2(95f, 102f), 20f) == JointId.HEAD)

    println("== Easing ==")
    for (e in Easing.entries) {
        if (e == Easing.HOLD) continue
        check("${e.name} endpoints", approx(e.apply(0f), 0f) && approx(e.apply(1f), 1f))
    }
    check("ease_in_out midpoint=0.5", approx(Easing.EASE_IN_OUT.apply(0.5f), 0.5f))
    check("hold is step", approx(Easing.HOLD.apply(0.5f), 0f) && approx(Easing.HOLD.apply(1f), 1f))

    println("== Track / timeline ==")
    val p0 = Pose.neutral(vec2(0f, 100f))
    val p1 = Pose.neutral(vec2(100f, 100f))
    val track = Track(listOf(Keyframe(0, p0, Easing.LINEAR), Keyframe(10, p1, Easing.LINEAR)))
    check("poseAt before first holds", track.poseAt(-5f).root.x == 0f)
    check("poseAt after last holds", track.poseAt(20f).root.x == 100f)
    check("poseAt mid interpolates", approx(track.poseAt(5f).root.x, 50f))
    val track2 = track.withKeyframe(Keyframe(5, Pose.neutral(vec2(50f, 120f))))
    check("withKeyframe inserts sorted", track2.keyframes.map { it.frame } == listOf(0, 5, 10))
    check("removeKeyframe", track2.removeKeyframeAt(5).keyframes.size == 2)
    check("hasKeyframeAt", track.hasKeyframeAt(0) && !track.hasKeyframeAt(3))
    var threw = false
    try { Track(listOf(Keyframe(5, p0), Keyframe(1, p1))) } catch (_: IllegalArgumentException) { threw = true }
    check("unsorted keyframes rejected", threw)

    println("== Motion presets ==")
    val base = Pose.neutral(vec2(360f, 400f))
    for (id in Presets.Id.entries) {
        val kfs = Presets.generate(id, base, 48)
        check("${id.name} non-empty", kfs.isNotEmpty())
        check("${id.name} sorted", kfs.map { it.frame } == kfs.map { it.frame }.sorted())
        check("${id.name} ends at cycle", kfs.last().frame == 48)
        check("${id.name} poses finite", kfs.all { abs(it.pose.root.x) < 10000 && abs(it.pose.root.y) < 10000 })
    }

    println("== Serialization round-trip ==")
    val proj = Project.newEmpty("Test Project").let {
        val cid = it.characters.first().id
        it.withKeyframe(cid, Keyframe(24, Pose.neutral(vec2(500f, 300f))))
          .copy(audioTracks = listOf(AudioTrack("a1", "content://test/audio.mp3", 12, 0.8f, "Song")))
    }
    val json = ProjectSerializer.encode(proj)
    check("JSON contains format marker", json.contains("stickmotion-studio"))
    val decoded = ProjectSerializer.decodeValidated(json)
    check("decode succeeds", decoded.isSuccess)
    val d = decoded.getOrThrow()
    check("round-trip name", d.name == proj.name)
    check("round-trip fps", d.fps == proj.fps)
    check("round-trip duration", d.durationFrames == proj.durationFrames)
    check("round-trip char count", d.characters.size == proj.characters.size)
    check("round-trip keyframe count", d.characters.first().track.keyframes.size == 2)
    check("round-trip kf2 root x", approx(d.characters.first().track.keyframes[1].pose.root.x, 500f, 0.5f))
    check("round-trip audio", d.audioTracks.size == 1 && approx(d.audioTracks.first().volume, 0.8f))

    println("== Import validation rejects bad files ==")
    val badFps = json.replaceFirst("\"fps\": 24", "\"fps\": 999")
    check("bad fps rejected", ProjectSerializer.decodeValidated(badFps).isFailure)
    val badFormat = json.replaceFirst("stickmotion-studio", "something-else")
    check("bad format rejected", ProjectSerializer.decodeValidated(badFormat).isFailure)
    check("garbage rejected", ProjectSerializer.decodeValidated("not json {{{").isFailure)

    println("== Undo/redo history ==")
    val h = History<Int>()
    h.push(1); h.push(2)
    check("canUndo", h.canUndo && !h.canRedo)
    check("undo returns prev", h.undo(3) == 2)
    check("redo returns next", h.redo(2) == 3)
    check("push clears redo", run { h.undo(3); h.push(9); !h.canRedo })

    println()
    println("RESULT: $passed passed, $failed failed")
    if (failed > 0) kotlin.system.exitProcess(1)
}
