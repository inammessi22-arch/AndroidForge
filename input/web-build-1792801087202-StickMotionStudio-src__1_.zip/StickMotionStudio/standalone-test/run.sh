#!/usr/bin/env bash
# Standalone core test runner — no Android SDK required.
# Downloads kotlinc 1.9.24 + kotlinx-serialization jars on first run, compiles
# the pure-Kotlin core + TestRunner.kt, and runs the suite.
set -euo pipefail
cd "$(dirname "$0")"
BUILD=../sms_build
mkdir -p "$BUILD"

if [ ! -x "$BUILD/kotlinc/bin/kotlinc" ]; then
  echo "Downloading Kotlin compiler 1.9.24..."
  curl -sL -o "$BUILD/kotlin-compiler.zip" \
    https://github.com/JetBrains/kotlin/releases/download/v1.9.24/kotlin-compiler-1.9.24.zip
  (cd "$BUILD" && unzip -q kotlin-compiler.zip)
fi
[ -f "$BUILD/ser-core.jar" ] || curl -sL -o "$BUILD/ser-core.jar" \
  https://repo1.maven.org/maven2/org/jetbrains/kotlinx/kotlinx-serialization-core-jvm/1.6.3/kotlinx-serialization-core-jvm-1.6.3.jar
[ -f "$BUILD/ser-json.jar" ] || curl -sL -o "$BUILD/ser-json.jar" \
  https://repo1.maven.org/maven2/org/jetbrains/kotlinx/kotlinx-serialization-json-jvm/1.6.3/kotlinx-serialization-json-jvm-1.6.3.jar
[ -f "$BUILD/ser-plugin.jar" ] || curl -sL -o "$BUILD/ser-plugin.jar" \
  https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-serialization-compiler-plugin/1.9.24/kotlin-serialization-compiler-plugin-1.9.24.jar

KOT="$BUILD/kotlinc/bin/kotlinc"
CP="$BUILD/ser-core.jar:$BUILD/ser-json.jar"
SRC="../app/src/main/java/com/stickmotion/studio/core/*.kt \
     ../app/src/main/java/com/stickmotion/studio/util/History.kt \
     ../app/src/main/java/com/stickmotion/studio/data/ProjectSerializer.kt \
     TestRunner.kt"
# shellcheck disable=SC2086
"$KOT" -Xplugin="$BUILD/ser-plugin.jar" -cp "$CP" $SRC -include-runtime -d "$BUILD/test.jar"
java -cp "$BUILD/test.jar:$CP" TestRunnerKt
