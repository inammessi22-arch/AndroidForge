# موبائل سے APK بنانے کی گائیڈ

یہ workflow GitHub Actions پر Android debug APK بنانے کی کوشش کرتا ہے۔ یہ APK کی کامیابی کی ضمانت نہیں؛ اگر Kotlin/Gradle compile error ہو تو workflow لاگ میں نظر آئے گا اور کوڈ درست کرنا ہوگا۔

## طریقہ
1. ZIP کو فون میں extract کریں۔
2. GitHub پر نیا خالی repository بنائیں، مثلاً `StickMotionStudio`۔
3. فون میں Termux استعمال کر کے extracted `StickMotionStudio` فولڈر کو GitHub repository میں push کیا جا سکتا ہے؛ یا کمپیوٹر پر پورا فولڈر upload کریں۔ صرف ZIP فائل repository میں ڈالنے سے build نہیں چلے گا، کیونکہ فائلیں extract ہونی چاہییں۔
4. Repository میں **Actions** کھولیں، **Build Android APK** workflow منتخب کریں، پھر **Run workflow** دبائیں۔
5. Run مکمل ہونے پر سبز نشان آئے تو run کھولیں اور **Artifacts** میں `stickmotion-studio-debug-apk` ڈاؤن لوڈ کریں۔
6. ZIP artifact کو فون میں extract کریں؛ اس میں `app-debug.apk` ہوگا۔ APK صرف اپنی جانچ کے لیے ہے، Play Store release کے لیے signed production build نہیں۔
7. اگر run سرخ/failed ہو تو Build log میں پہلے `e:` یا `FAILURE:` والی error شیئر کریں تاکہ اسے درست کیا جا سکے۔

## احتیاط
- GitHub میں passwords، API keys یا signing keystore اپلوڈ نہ کریں۔
- پہلے APK اپنے فون پر test کریں۔ MP4 export سمیت تمام فیچرز کی عملی جانچ ضروری ہے۔
