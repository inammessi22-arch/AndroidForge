# موبائل سے APK بنانے کا طریقہ (GitHub Actions)

یہ فائل خود APK نہیں ہے؛ یہ GitHub پر Android build چلانے کی configuration ہے۔ APK صرف اسی وقت ملے گی جب build کامیاب ہو۔

## ضروری بات
- GitHub پر ایک repository بنائیں اور اس ZIP کے اندر موجود `StickMotionStudio` فولڈر کے تمام اصل project files repository کے root میں upload کریں۔ صرف ZIP فائل کو repository میں ڈالنے سے workflow نہیں چلے گا۔
- `.github/workflows/android-apk.yml` بھی ضرور upload ہو؛ Android source repository میں `.github/workflows/` کے اندر یہ فائل ہونی چاہیے۔
- Repository کو Public رکھنا عام طور پر GitHub Actions کے مفت استعمال کے لیے آسان ہے؛ نجی repository پر موجودہ account limits لاگو ہو سکتی ہیں۔

## Build چلائیں
1. موبائل کے Chrome میں GitHub کھولیں اور سائن اِن کریں۔
2. نیا repository بنائیں، مثلاً `StickMotionStudio`۔
3. ZIP کو موبائل کے File Manager میں extract کریں۔
4. Extract کیے گئے فولڈر کے اندر کے تمام files/folders repository کے root میں upload کریں۔ فولڈر کے اندر ایک اور `StickMotionStudio` فولڈر بطور nested root نہ بنائیں۔
5. Upload مکمل ہونے کے بعد repository میں `.github/workflows/android-apk.yml` کی موجودگی چیک کریں۔
6. Repository کے **Actions** tab میں **Build Android APK** workflow کھولیں۔ اگر workflow نظر آئے تو **Run workflow** دبائیں؛ ورنہ main branch پر source push/upload ہونے سے خودکار run بھی شروع ہو سکتا ہے۔
7. Build مکمل ہونے تک انتظار کریں۔ سرخ ❌ کا مطلب build ناکام ہوا ہے؛ اس صورت میں log کی آخری error lines دیکھ کر code درست کرنا ہوگا۔
8. سبز ✓ کامیابی کے بعد اسی run کے صفحے کے نیچے **Artifacts** میں `StickMotionStudio-debug-apk` ڈاؤن لوڈ کریں۔ ZIP artifact کو extract کریں؛ اندر `app-debug.apk` ہوگی۔
9. APK صرف اپنے اعتماد والے source سے install کریں۔ Android اگر اجازت مانگے تو صرف اسی فائل مینیجر/براؤزر کے لیے “Install unknown apps” اجازت دیں جس سے APK کھول رہے ہیں۔

## اہم
یہ **debug APK** ہے، Play Store کے لیے signed release نہیں۔ اصل Android build ابھی اس ماحول میں compile نہیں ہوئی، اس لیے پہلے CI build اور موبائل پر عملی ٹیسٹنگ ضروری ہے۔ Build error آئے تو GitHub Actions log کی error والی آخری 30–50 lines محفوظ کریں؛ ان کے بغیر یہ دعویٰ نہیں کیا جا سکتا کہ ایپ compile ہو گئی ہے۔
